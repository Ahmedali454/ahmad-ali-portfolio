import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowLeft, Search, RotateCcw, Plus, X, AlertTriangle, MapPin, Gauge, Calendar, Heart, Mail, Store, ShoppingCart, Check, Tag } from 'lucide-react';
import { Key } from './kit';

type Cat = 'Excavator' | 'Loader' | 'Crane' | 'Bulldozer' | 'Dump Truck' | 'Generator';
type Deal = 'Sale' | 'Rent';
type Item = { id: string; title: string; cat: Cat; deal: Deal; price: number; city: string; year: number; hours: number; seller: string; mine?: boolean; sold?: boolean; desc: string };
type Enquiry = { id: string; itemId: string; name: string; phone: string; msg: string; ts: string };
type DB = { items: Item[]; enq: Enquiry[]; fav: string[]; seq: number };

const CATS: Cat[] = ['Excavator', 'Loader', 'Crane', 'Bulldozer', 'Dump Truck', 'Generator'];
const CITIES = ['Hassan Abdal', 'Islamabad', 'Rawalpindi', 'Lahore', 'Karachi', 'Peshawar', 'Haripur'];
const TONE: Record<Cat, string> = { Excavator: '#ffd527', Loader: '#34eadd', Crane: '#ff4f81', Bulldozer: '#ffb3c8', 'Dump Truck': '#a8f5ee', Generator: '#fff2a8' };
const KEY = 'aa-heavyequip-v1';
const pkr = (n: number) => 'Rs ' + n.toLocaleString('en-PK');

function seed(): DB {
  const raw: [string, Cat, Deal, number, string, number, number, string][] = [
    ['CAT 320D Hydraulic Excavator', 'Excavator', 'Sale', 14500000, 'Islamabad', 2016, 7200, 'Khan Machinery'],
    ['Komatsu PC200-8 Excavator', 'Excavator', 'Rent', 45000, 'Rawalpindi', 2014, 9800, 'Pindi Plant Hire'],
    ['JCB 3CX Backhoe Loader', 'Loader', 'Sale', 6800000, 'Hassan Abdal', 2018, 4100, 'Abdal Traders'],
    ['CAT 950H Wheel Loader', 'Loader', 'Rent', 38000, 'Lahore', 2012, 11200, 'Punjab Earthmovers'],
    ['Tadano 25-Ton Mobile Crane', 'Crane', 'Rent', 65000, 'Karachi', 2011, 8600, 'Port City Cranes'],
    ['XCMG QY50 50-Ton Crane', 'Crane', 'Sale', 22500000, 'Lahore', 2017, 5300, 'Lift Pro'],
    ['Komatsu D65 Bulldozer', 'Bulldozer', 'Sale', 11800000, 'Peshawar', 2013, 10400, 'Frontier Heavy'],
    ['CAT D6R Dozer', 'Bulldozer', 'Rent', 52000, 'Haripur', 2010, 12900, 'Hazara Equip'],
    ['Hino 10-Wheeler Dump Truck', 'Dump Truck', 'Sale', 7400000, 'Rawalpindi', 2019, 3100, 'Pindi Plant Hire'],
    ['Isuzu Giga Dump Truck', 'Dump Truck', 'Rent', 28000, 'Islamabad', 2015, 6900, 'Khan Machinery'],
    ['Cummins 250 kVA Generator', 'Generator', 'Sale', 3900000, 'Hassan Abdal', 2020, 1800, 'Abdal Traders'],
    ['Perkins 100 kVA Generator', 'Generator', 'Rent', 9000, 'Karachi', 2018, 4200, 'Port City Cranes'],
  ];
  const items = raw.map(([title, cat, deal, price, city, year, hours, seller], i) => ({
    id: `EQ-${201 + i}`, title, cat, deal, price, city, year, hours, seller,
    desc: `${cat} in working condition, ${hours.toLocaleString()} engine hours. Inspection welcome in ${city}.`,
  }));
  return { items, enq: [], fav: [], seq: 213 };
}
function load(): DB { try { const s = localStorage.getItem(KEY); if (s) return JSON.parse(s); } catch { /* ignore */ } return seed(); }

/** Simple original machine illustrations. */
function Machine({ cat }: { cat: Cat }) {
  const s = { stroke: '#000', strokeWidth: 4, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const };
  const wheels = (xs: number[], y = 112, r = 14) => xs.map((x) => <g key={x}><circle cx={x} cy={y} r={r} fill="#222" {...s} /><circle cx={x} cy={y} r={r / 2.6} fill="#ddd" /></g>);
  const track = <><rect x="30" y="100" width="120" height="26" rx="13" fill="#333" {...s} />{[45, 70, 95, 120, 135].map((x) => <circle key={x} cx={x} cy={113} r="6" fill="#999" />)}</>;
  return (
    <svg viewBox="0 0 200 140" className="w-full h-full">
      <path d="M0 128 H200" stroke="#000" strokeWidth="3" />
      {cat === 'Excavator' && <>{track}<rect x="50" y="62" width="80" height="38" rx="6" fill="#ffd527" {...s} /><rect x="56" y="38" width="34" height="28" rx="4" fill="#bdf" {...s} /><path d="M128 72 L165 30 L190 70" fill="none" {...s} strokeWidth="9" /><path d="M180 66 l14 20 h-22 z" fill="#555" {...s} /></>}
      {cat === 'Loader' && <>{wheels([60, 140], 108, 20)}<rect x="40" y="62" width="120" height="36" rx="8" fill="#34eadd" {...s} /><rect x="60" y="30" width="44" height="34" rx="4" fill="#bdf" {...s} /><path d="M160 78 L178 92" {...s} strokeWidth="8" /><path d="M170 80 h26 v28 h-30 z" fill="#555" {...s} /></>}
      {cat === 'Crane' && <>{wheels([45, 80, 140, 170], 112, 12)}<rect x="30" y="80" width="155" height="22" rx="5" fill="#ff4f81" {...s} /><rect x="140" y="56" width="34" height="26" rx="4" fill="#bdf" {...s} /><path d="M60 80 L150 8" {...s} strokeWidth="9" /><path d="M150 8 V50" {...s} strokeWidth="2" /><path d="M144 50 h12 l-6 10 z" fill="#555" {...s} /></>}
      {cat === 'Bulldozer' && <>{track}<rect x="55" y="66" width="80" height="34" rx="6" fill="#ffb3c8" {...s} /><rect x="64" y="38" width="38" height="30" rx="4" fill="#bdf" {...s} /><path d="M152 60 c12 10 12 50 0 66 h10 c10 -16 10 -56 0 -66 z" fill="#555" {...s} /><path d="M135 84 h18" {...s} strokeWidth="6" /></>}
      {cat === 'Dump Truck' && <>{wheels([50, 120, 150], 110, 15)}<rect x="20" y="56" width="44" height="42" rx="6" fill="#bdf" {...s} /><path d="M70 50 L185 40 L180 96 H70 z" fill="#a8f5ee" {...s} /><rect x="16" y="94" width="172" height="8" fill="#333" {...s} /></>}
      {cat === 'Generator' && <><rect x="30" y="50" width="140" height="66" rx="8" fill="#fff2a8" {...s} />{[0, 1, 2, 3, 4, 5].map((i) => <path key={i} d={`M${48 + i * 12} 64 v38`} {...s} strokeWidth="3" />)}<rect x="122" y="62" width="34" height="22" rx="3" fill="#222" {...s} /><path d="M135 66 l-5 8 h8 l-5 8" stroke="#ffd527" strokeWidth="3" fill="none" /><path d="M40 116 v10 M160 116 v10" {...s} /><path d="M150 50 v-16 h10" fill="none" {...s} /></>}
    </svg>
  );
}

const input = 'w-full rounded-xl border-2 border-black px-3 py-2 font-serif bg-white text-black outline-none focus:ring-4 focus:ring-yellow/60';

function Detail({ it, db, set, onClose }: { it: Item; db: DB; set: (f: (d: DB) => DB) => void; onClose: () => void }) {
  const [f, setF] = useState({ name: '', phone: '', msg: `Is the ${it.title} still available?` }); const [err, setErr] = useState(''); const [sent, setSent] = useState(false);
  const send = () => {
    if (f.name.trim().length < 3) return setErr('Please enter your name.');
    if (!/^03\d{2}-?\d{7}$/.test(f.phone.trim())) return setErr('Phone format: 03XX-XXXXXXX');
    if (f.msg.trim().length < 5) return setErr('Message is too short.');
    set((d) => ({ ...d, enq: [{ id: `ENQ-${d.enq.length + 1}`, itemId: it.id, name: f.name.trim(), phone: f.phone.trim(), msg: f.msg.trim(), ts: new Date().toISOString() }, ...d.enq] }));
    setErr(''); setSent(true);
  };
  return (
    <motion.div className="fixed inset-0 z-[80] bg-black/60 grid place-items-center p-3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.div initial={{ y: 40, scale: 0.96 }} animate={{ y: 0, scale: 1 }} exit={{ y: 30, opacity: 0 }} onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl max-h-[92vh] overflow-auto rounded-[22px] border-2 border-black bg-white text-black">
        <div className="grid md:grid-cols-2">
          <div className="p-6 border-b-2 md:border-b-0 md:border-r-2 border-black" style={{ background: TONE[it.cat] }}><Machine cat={it.cat} /></div>
          <div className="p-5">
            <div className="flex justify-between gap-2"><span className="text-[11px] font-bold uppercase border-2 border-black rounded-full px-2 py-0.5 bg-white">{it.deal === 'Sale' ? 'For sale' : 'For rent'}</span><button onClick={onClose} aria-label="Close"><X className="w-5 h-5" /></button></div>
            <h3 className="display text-3xl mt-2 leading-tight">{it.title}</h3>
            <div className="display text-2xl mt-1">{pkr(it.price)}{it.deal === 'Rent' && <span className="font-serif text-sm"> / day</span>}</div>
            <div className="grid grid-cols-3 gap-2 mt-3 text-xs font-serif">
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{it.city}</span><span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{it.year}</span><span className="flex items-center gap-1"><Gauge className="w-3 h-3" />{it.hours.toLocaleString()} h</span>
            </div>
            <p className="font-serif text-sm mt-3">{it.desc}</p>
            <div className="font-serif text-xs mt-1 text-black/60">Seller: {it.seller}</div>
            {it.sold ? <div className="mt-4 font-bold text-[#d6164e]">This listing is sold.</div> : sent ? (
              <div className="mt-4 rounded-xl border-2 border-black bg-[#36d07e] p-3 font-bold flex items-center gap-2"><Check className="w-4 h-4" /> Enquiry sent to {it.seller}.</div>
            ) : (
              <div className="mt-4 grid gap-2">
                <div className="display text-lg">Contact seller</div>
                <input className={input} placeholder="Your name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
                <input className={input} placeholder="03XX-XXXXXXX" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
                <textarea className={input} rows={2} value={f.msg} onChange={(e) => setF({ ...f, msg: e.target.value })} />
                {err && <div className="text-xs text-[#d6164e] font-bold flex items-center gap-1"><AlertTriangle className="w-3 h-3" />{err}</div>}
                <Key color="yellow" onClick={send}><Mail className="w-4 h-4" /> Send enquiry</Key>
              </div>
            )}
            <div className="mt-3 text-xs font-serif italic">{db.enq.filter((e) => e.itemId === it.id).length} enquiries on this listing</div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function Browse({ db, set }: { db: DB; set: (f: (d: DB) => DB) => void }) {
  const [q, setQ] = useState(''); const [cat, setCat] = useState<'All' | Cat>('All'); const [deal, setDeal] = useState<'All' | Deal>('All');
  const [city, setCity] = useState('All'); const [sort, setSort] = useState('new'); const [favOnly, setFavOnly] = useState(false); const [open, setOpen] = useState<Item | null>(null);
  const list = useMemo(() => {
    const l = db.items.filter((i) => (cat === 'All' || i.cat === cat) && (deal === 'All' || i.deal === deal) && (city === 'All' || i.city === city) && (!favOnly || db.fav.includes(i.id)) && (i.title + i.seller + i.city).toLowerCase().includes(q.toLowerCase()));
    return [...l].sort((a, b) => sort === 'low' ? a.price - b.price : sort === 'high' ? b.price - a.price : sort === 'year' ? b.year - a.year : 0);
  }, [db, q, cat, deal, city, sort, favOnly]);
  const fav = (id: string) => set((d) => ({ ...d, fav: d.fav.includes(id) ? d.fav.filter((x) => x !== id) : [...d.fav, id] }));
  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-3">
        {(['All', ...CATS] as const).map((c, i) => <Key key={c} sm serif color={(['pink', 'yellow', 'teal', 'white', 'dark', 'white', 'teal'] as const)[i]} active={cat === c} onClick={() => setCat(c)}><span className="text-[15px]">{c}</span></Key>)}
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-2 mb-5">
        <div className="relative lg:col-span-2"><Search className="w-4 h-4 absolute left-3 top-3 text-black/50" /><input className={input + ' pl-9'} placeholder="Search machines, sellers, cities…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <select className={input} value={deal} onChange={(e) => setDeal(e.target.value as any)}><option value="All">Buy or rent</option><option value="Sale">For sale</option><option value="Rent">For rent</option></select>
        <select className={input} value={city} onChange={(e) => setCity(e.target.value)}><option value="All">All cities</option>{CITIES.map((c) => <option key={c}>{c}</option>)}</select>
        <select className={input} value={sort} onChange={(e) => setSort(e.target.value)}><option value="new">Newest</option><option value="low">Price: low → high</option><option value="high">Price: high → low</option><option value="year">Model year</option></select>
      </div>
      <div className="flex items-center justify-between mb-3 dark:text-white">
        <div className="font-serif italic text-sm">{list.length} listings</div>
        <button onClick={() => setFavOnly(!favOnly)} className={`text-sm font-bold flex items-center gap-1 rounded-full border-2 border-black px-3 py-1 ${favOnly ? 'bg-pink text-black' : 'bg-white text-black'}`}><Heart className="w-4 h-4" fill={favOnly ? '#000' : 'none'} /> Saved ({db.fav.length})</button>
      </div>
      <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <AnimatePresence mode="popLayout">
          {list.map((it) => (
            <motion.article layout key={it.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}
              className="group rounded-[20px] border-2 border-black bg-white text-black overflow-hidden hover:shadow-[6px_7px_0_#000] hover:-translate-y-1 transition">
              <button className="block w-full text-left" onClick={() => setOpen(it)}>
                <div className="relative h-40 p-4 border-b-2 border-black" style={{ background: TONE[it.cat] }}>
                  <div className="h-full transition-transform duration-500 group-hover:scale-105"><Machine cat={it.cat} /></div>
                  <span className={`absolute top-3 left-3 text-[11px] font-bold uppercase px-2 py-0.5 rounded-full border-2 border-black ${it.deal === 'Sale' ? 'bg-white' : 'bg-black text-white'}`}>{it.deal === 'Sale' ? 'For sale' : 'For rent'}</span>
                  {it.sold && <span className="absolute inset-0 grid place-items-center bg-white/60 display text-4xl -rotate-6">Sold</span>}
                </div>
                <div className="p-4">
                  <div className="display text-xl leading-tight">{it.title}</div>
                  <div className="display text-lg mt-1">{pkr(it.price)}{it.deal === 'Rent' && <span className="font-serif text-xs"> / day</span>}</div>
                  <div className="mt-2 flex gap-3 text-xs font-serif text-black/70"><span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{it.city}</span><span>{it.year}</span><span>{it.hours.toLocaleString()} h</span></div>
                </div>
              </button>
              <div className="px-4 pb-4 -mt-1 flex justify-between items-center">
                <span className="text-xs font-serif italic">{it.seller}</span>
                <button onClick={() => fav(it.id)} aria-label="Save" className="w-9 h-9 rounded-full border-2 border-black grid place-items-center hover:bg-pink"><Heart className="w-4 h-4" fill={db.fav.includes(it.id) ? '#ff4f81' : 'none'} /></button>
              </div>
            </motion.article>
          ))}
        </AnimatePresence>
      </motion.div>
      {!list.length && <div className="text-center font-serif italic py-10 dark:text-white">No machines match these filters.</div>}
      <AnimatePresence>{open && <Detail it={db.items.find((x) => x.id === open.id)!} db={db} set={set} onClose={() => setOpen(null)} />}</AnimatePresence>
    </div>
  );
}

function Sell({ db, set, done }: { db: DB; set: (f: (d: DB) => DB) => void; done: () => void }) {
  const [f, setF] = useState({ title: '', cat: 'Excavator' as Cat, deal: 'Sale' as Deal, price: '', city: 'Hassan Abdal', year: '', hours: '', desc: '' });
  const [err, setErr] = useState<Record<string, string>>({});
  const save = () => {
    const e: Record<string, string> = {}; const yr = +f.year, price = +f.price, hours = +f.hours;
    if (f.title.trim().length < 5) e.title = 'Title must have at least 5 characters';
    if (!price || price < (f.deal === 'Rent' ? 1000 : 100000)) e.price = f.deal === 'Rent' ? 'Daily rent must be at least Rs 1,000' : 'Sale price must be at least Rs 100,000';
    if (!yr || yr < 1980 || yr > new Date().getFullYear()) e.year = `Year between 1980 and ${new Date().getFullYear()}`;
    if (f.hours === '' || hours < 0) e.hours = 'Enter engine hours (0 or more)';
    setErr(e); if (Object.keys(e).length) return;
    const it: Item = { id: `EQ-${db.seq}`, title: f.title.trim(), cat: f.cat, deal: f.deal, price, city: f.city, year: yr, hours, seller: 'You', mine: true, desc: f.desc.trim() || `${f.cat} listed by you in ${f.city}.` };
    set((d) => ({ ...d, items: [it, ...d.items], seq: d.seq + 1 })); done();
  };
  const field = (k: keyof typeof f, label: string, el: React.ReactNode) => (
    <label className="grid gap-1"><span className="font-display uppercase text-sm">{label}</span>{el}{err[k] && <span className="text-xs text-[#d6164e] font-bold flex items-center gap-1"><AlertTriangle className="w-3 h-3" />{err[k]}</span>}</label>
  );
  return (
    <div className="grid lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2 rounded-2xl border-2 border-black bg-white text-black p-5 grid sm:grid-cols-2 gap-3">
        <div className="sm:col-span-2">{field('title', 'Title', <input className={input} placeholder="e.g. Hitachi ZX200 Excavator" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />)}</div>
        {field('cat', 'Category', <select className={input} value={f.cat} onChange={(e) => setF({ ...f, cat: e.target.value as Cat })}>{CATS.map((c) => <option key={c}>{c}</option>)}</select>)}
        {field('deal', 'Listing type', <select className={input} value={f.deal} onChange={(e) => setF({ ...f, deal: e.target.value as Deal })}><option value="Sale">For sale</option><option value="Rent">For rent (per day)</option></select>)}
        {field('price', f.deal === 'Rent' ? 'Rent per day (Rs)' : 'Price (Rs)', <input className={input} inputMode="numeric" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value.replace(/\D/g, '') })} />)}
        {field('city', 'City', <select className={input} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })}>{CITIES.map((c) => <option key={c}>{c}</option>)}</select>)}
        {field('year', 'Model year', <input className={input} inputMode="numeric" value={f.year} onChange={(e) => setF({ ...f, year: e.target.value.replace(/\D/g, '').slice(0, 4) })} />)}
        {field('hours', 'Engine hours', <input className={input} inputMode="numeric" value={f.hours} onChange={(e) => setF({ ...f, hours: e.target.value.replace(/\D/g, '') })} />)}
        <div className="sm:col-span-2">{field('desc', 'Description', <textarea className={input} rows={3} value={f.desc} onChange={(e) => setF({ ...f, desc: e.target.value })} />)}</div>
        <div className="sm:col-span-2"><Key color="yellow" onClick={save}><Plus className="w-4 h-4" /> Publish listing</Key></div>
      </div>
      <div>
        <div className="rounded-2xl border-2 border-black overflow-hidden bg-white text-black">
          <div className="h-40 p-4 border-b-2 border-black" style={{ background: TONE[f.cat] }}><Machine cat={f.cat} /></div>
          <div className="p-4"><div className="display text-xl">{f.title || 'Your listing title'}</div><div className="display text-lg">{f.price ? pkr(+f.price) : 'Rs —'}{f.deal === 'Rent' && <span className="font-serif text-xs"> / day</span>}</div><div className="font-serif text-xs mt-1">{f.city} · {f.year || 'year'} · {f.hours || 0} h</div></div>
        </div>
        <div className="font-serif italic text-xs mt-2 dark:text-white/70">Live preview — the card buyers will see.</div>
      </div>
    </div>
  );
}

function Seller({ db, set }: { db: DB; set: (f: (d: DB) => DB) => void }) {
  const mine = db.items.filter((i) => i.mine);
  const enq = db.enq;
  const title = (id: string) => db.items.find((i) => i.id === id)?.title ?? id;
  return (
    <div className="grid lg:grid-cols-2 gap-5">
      <div className="rounded-2xl border-2 border-black bg-white text-black p-5">
        <div className="display text-2xl">My listings</div>
        {!mine.length && <div className="font-serif italic text-sm mt-2">No listings yet — use “Sell equipment”.</div>}
        <ul className="mt-3 grid gap-2">
          {mine.map((i) => (
            <li key={i.id} className="flex items-center gap-3 rounded-xl border-2 border-black p-2">
              <div className="w-14 h-10 rounded-lg border-2 border-black p-0.5" style={{ background: TONE[i.cat] }}><Machine cat={i.cat} /></div>
              <div className="flex-1 min-w-0"><div className="font-bold truncate">{i.title}</div><div className="text-xs font-serif">{pkr(i.price)} · {db.enq.filter((e) => e.itemId === i.id).length} enquiries</div></div>
              <button onClick={() => set((d) => ({ ...d, items: d.items.map((x) => x.id === i.id ? { ...x, sold: !x.sold } : x) }))} className={`text-xs font-bold rounded-lg border-2 border-black px-2 py-1 ${i.sold ? 'bg-black text-white' : 'bg-[#36d07e]'}`}><Tag className="w-3 h-3 inline" /> {i.sold ? 'Sold' : 'Mark sold'}</button>
            </li>
          ))}
        </ul>
      </div>
      <div className="rounded-2xl border-2 border-black bg-white text-black p-5">
        <div className="display text-2xl">Enquiries</div>
        {!enq.length && <div className="font-serif italic text-sm mt-2">Open any listing and send an enquiry to see it here.</div>}
        <ul className="mt-3 grid gap-2 max-h-96 overflow-auto">
          {enq.map((e) => <li key={e.id} className="rounded-xl border-2 border-black p-3"><div className="flex justify-between text-xs font-bold"><span>{e.name} · {e.phone}</span><span>{new Date(e.ts).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</span></div><div className="font-serif text-sm mt-1">{e.msg}</div><div className="text-[11px] font-serif italic text-black/60 mt-1">{title(e.itemId)}</div></li>)}
        </ul>
      </div>
    </div>
  );
}

const TABS = [
  { k: 'buy', l: 'Browse', I: ShoppingCart, c: 'yellow' },
  { k: 'sell', l: 'Sell equipment', I: Plus, c: 'teal' },
  { k: 'seller', l: 'Seller dashboard', I: Store, c: 'pink' },
] as const;

export default function HeavyEquipLab() {
  const [db, setDb] = useState<DB>(load);
  const [tab, setTab] = useState<(typeof TABS)[number]['k']>('buy');
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch { /* ignore */ } }, [db]);
  useEffect(() => { window.scrollTo(0, 0); }, []);
  return (
    <main className="min-h-screen bg-[#f3f3f3] dark:bg-coal text-black">
      <header className="relative bg-black text-white pt-24 pb-10 overflow-hidden">
        <div className="absolute right-0 bottom-0 w-[340px] opacity-40 hidden sm:block" aria-hidden><Machine cat="Excavator" /></div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-8">
          <a href="#work" className="inline-flex items-center gap-2 font-serif text-white/80 hover:text-yellow mb-5"><ArrowLeft className="w-4 h-4" /> Back to portfolio</a>
          <div className="serif-i text-lg text-yellow">Final Year Project · live demo</div>
          <h1 className="display text-[clamp(44px,8vw,104px)]">HeavyEquip Marketplace</h1>
          <p className="font-serif text-white/80 max-w-2xl mt-3">Buy, sell and rent heavy equipment — listings, filters, enquiries and a seller dashboard. Built by Ahmed in Oracle APEX as his final year project; recreated here so you can try it. Data stays in your browser.</p>
        </div>
      </header>
      <div className="sticky top-0 z-30 bg-[#f3f3f3]/95 dark:bg-coal/95 backdrop-blur border-b-2 border-black">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 py-3 flex gap-2 overflow-x-auto no-scrollbar items-center pr-[190px]">
          {TABS.map(({ k, l, I, c }) => <Key key={k} sm serif color={c as any} active={tab === k} onClick={() => setTab(k)}><I className="w-4 h-4" /><span className="text-[15px] whitespace-nowrap">{l}</span></Key>)}
          <Key sm color="white" onClick={() => setDb(seed())} title="Reset demo data"><RotateCcw className="w-4 h-4" /></Key>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-4 sm:px-8 py-8">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.25 }}>
            {tab === 'buy' && <Browse db={db} set={setDb} />}
            {tab === 'sell' && <Sell db={db} set={setDb} done={() => setTab('seller')} />}
            {tab === 'seller' && <Seller db={db} set={setDb} />}
          </motion.div>
        </AnimatePresence>
        <div className="mt-8 flex items-center gap-2 text-xs font-serif italic dark:text-white/70"><AlertTriangle className="w-3 h-3" /> Demo with sample listings and prices — not real offers.</div>
      </div>
    </main>
  );
}

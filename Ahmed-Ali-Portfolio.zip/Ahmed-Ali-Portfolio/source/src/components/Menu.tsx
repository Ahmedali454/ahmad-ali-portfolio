import { useEffect, useState } from 'react';
import { AnimatePresence, motion, useScroll, useSpring } from 'motion/react';
import { Menu as MenuIcon, X, Home, FolderOpen, Wrench, Info, GraduationCap, PenLine, Heart, Package, Truck, Mail, Github, Linkedin, Moon, Sun, Sparkles } from 'lucide-react';
import { Key, Logo } from './kit';
import { PROFILE, gmailCompose, waLink } from '../data';
import { BrandIcon } from '../lib/ui';

export const openChat = (prompt?: string) => window.dispatchEvent(new CustomEvent('open-chat', { detail: prompt }));

const LINKS = [
  { label: 'Work', href: '#work', color: 'teal', I: FolderOpen },
  { label: 'Services', href: '#services', color: 'white', I: Wrench },
  { label: 'About', href: '#about', color: 'yellow', I: Info },
  { label: 'Education', href: '#education', color: 'pink', I: GraduationCap },
  { label: 'Toolkit', href: '#toolkit', color: 'white', I: Sparkles },
  { label: 'Writing', href: '#writing', color: 'white', I: PenLine },
  { label: 'Contact', href: '#contact', color: 'dark', I: Heart },
  { label: 'CareBox Lab', href: '#carebox-lab', color: 'green', I: Package },
  { label: 'HeavyEquip Lab', href: '#heavyequip-lab', color: 'yellow', I: Truck },
] as const;

export function Menu({ dark, toggleTheme }: { dark: boolean; toggleTheme: () => void; onLab?: boolean }) {
  const [open, setOpen] = useState(false);
  const { scrollYProgress } = useScroll();
  const x = useSpring(scrollYProgress, { stiffness: 120, damping: 24 });

  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []);

  return (
    <>
      <motion.div className="fixed top-0 left-0 right-0 h-[4px] bg-yellow origin-left z-[60]" style={{ scaleX: x }} />
      <div className="fixed top-4 right-4 sm:right-6 z-50 flex gap-2">
        <Key color="white" icon onClick={toggleTheme} title={dark ? 'Light mode' : 'Dark mode'}>
          {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </Key>
        <Key color="teal" serif onClick={() => setOpen(true)} title="Open menu">
          <span className="text-[15px]">Menu</span><MenuIcon className="w-4 h-4" />
        </Key>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div className="fixed inset-0 z-[70] bg-black/55 backdrop-blur-[6px]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}>
            <motion.nav
              initial={{ opacity: 0, y: -24, scale: 0.96, rotate: -1.5 }} animate={{ opacity: 1, y: 0, scale: 1, rotate: 0 }} exit={{ opacity: 0, y: -16, scale: 0.97 }}
              transition={{ type: 'spring', stiffness: 260, damping: 22 }}
              onClick={(e) => e.stopPropagation()}
              className="absolute right-3 sm:right-6 top-3 sm:top-6 w-[min(400px,calc(100vw-24px))] bg-white text-black rounded-[22px] border-2 border-black p-5 sm:p-6 flex flex-col"
              style={{ minHeight: 'min(560px, calc(100vh - 24px))' }} aria-label="Main menu">
              <div className="flex flex-wrap gap-2.5">
                <Key icon href="#top" onClick={() => setOpen(false)} title="Home"><Home className="w-4 h-4" /></Key>
                {LINKS.map(({ label, href, color, I }, i) => (
                  <motion.span key={label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.04 * i }}>
                    <Key color={color as any} serif href={href} onClick={() => setOpen(false)}>
                      <span className="text-[15px]">{label}</span><I className="w-4 h-4" />
                    </Key>
                  </motion.span>
                ))}
                <Key icon onClick={() => setOpen(false)} title="Close menu"><X className="w-4 h-4" /></Key>
              </div>
              <button onClick={() => { setOpen(false); openChat(); }} className="mt-5 text-left rounded-2xl border-2 border-black bg-yellow p-4 hover:-rotate-1 transition">
                <div className="display text-2xl">Ask my AI ↗</div>
                <div className="serif-i text-sm mt-1">Skills, projects, hiring — answers in any language.</div>
              </button>
              <div className="mt-auto pt-5 border-t border-black/15 flex items-center justify-between gap-3">
                <div className="bg-black rounded-lg p-2"><Logo /></div>
                <div className="flex gap-2">
                  <Key icon sm href={gmailCompose()} title="Gmail"><Mail className="w-4 h-4" /></Key>
                  <Key icon sm href={PROFILE.github} title="GitHub"><Github className="w-4 h-4" /></Key>
                  <Key icon sm href={PROFILE.linkedin} title="LinkedIn"><Linkedin className="w-4 h-4" /></Key>
                  <Key icon sm href={waLink('Hi Ahmed! I visited your portfolio.')} title="WhatsApp"><BrandIcon name="whatsapp" size={16} /></Key>
                </div>
              </div>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

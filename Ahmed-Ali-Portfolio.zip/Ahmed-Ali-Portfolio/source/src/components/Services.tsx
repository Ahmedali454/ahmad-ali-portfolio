import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Code2, Database, ShieldCheck, Brain, X, Check } from 'lucide-react';
import { Key } from './kit';
import { Streaks } from './Intro';
import { SERVICES, SKILLS, gmailCompose, waLink } from '../data';
import { BrandIcon } from '../lib/ui';
import { openChat } from './Menu';

const LOGOS = [
  ['oracle', 'Oracle APEX', '#f80000'], ['oracle', 'Oracle Database', '#c74634'], ['sql', 'SQL', '#00618a'], ['db', 'PL/SQL', '#c2410c'],
  ['plug', 'REST APIs', '#10b981'], ['json', 'JSON', 'var(--ink)'], ['js', 'JavaScript', '#d4b400'], ['html', 'HTML5', '#e34f26'],
  ['css', 'CSS3', '#1572b6'], ['dash', 'Dashboards', '#8b5cf6'], ['lock', 'Authentication', '#ef4444'], ['github', 'GitHub', '#181717'],
] as const;

export function LogoStrip() {
  const row = [...LOGOS, ...LOGOS];
  return (
    <div className="bg-paper border-y-2 border-black dark:border-[#2c2b2b] py-7 overflow-hidden" aria-label="Technologies">
      <div className="marquee gap-14 pr-14" style={{ ['--dur' as any]: '45s' }}>
        {row.map(([k, n, c], i) => (
          <div key={i} className="flex items-center gap-3 shrink-0 grayscale-0 hover:-translate-y-1 transition">
            <BrandIcon name={k} size={38} color={k === 'github' ? 'var(--ink)' : c} />
            <span className="font-display font-semibold text-2xl text-ink whitespace-nowrap">{n}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

const SV = [
  { I: Database, color: 'white', skills: ['Dynamic Actions', 'Interactive Reports', 'Interactive Grids', 'Page & App Processes', 'Shared Components'] },
  { I: Code2, color: 'teal', skills: ['Oracle Database', 'SQL', 'PL/SQL Packages', 'Data Validation', 'Troubleshooting'] },
  { I: ShieldCheck, color: 'yellow', skills: ['REST APIs', 'JSON', 'API Authentication', 'Data Synchronization'] },
  { I: Brain, color: 'dark', skills: ['Dashboards', 'Forms & Workflows', 'JavaScript', 'HTML', 'CSS'] },
] as const;

function BugArt() {
  return (
    <svg viewBox="0 0 220 220" className="w-full h-full" aria-hidden>
      <g className="bob" style={{ transformOrigin: '110px 110px' }}>
        <ellipse cx="96" cy="120" rx="34" ry="42" fill="#ff4f81" stroke="#000" strokeWidth="4" />
        <path d="M96 78 v84" stroke="#000" strokeWidth="4" />
        <circle cx="96" cy="72" r="16" fill="#131212" stroke="#fff" strokeWidth="3" />
        <circle cx="90" cy="70" r="3" fill="#fff" /><circle cx="102" cy="70" r="3" fill="#fff" />
        {[-1, 1].map((s) => [96, 120, 144].map((y) => <path key={s + '' + y} d={`M${96 + s * 32} ${y} l${s * 22} ${-8}`} stroke="#fff" strokeWidth="4" strokeLinecap="round" />))}
      </g>
      <circle cx="150" cy="140" r="40" fill="#34eadd33" stroke="#fff" strokeWidth="8" />
      <path d="M178 170 l30 32" stroke="#ffd527" strokeWidth="14" strokeLinecap="round" />
    </svg>
  );
}
function RocketArt() {
  return (
    <svg viewBox="0 0 160 260" className="w-full h-full" aria-hidden>
      <g className="bob">
        <path d="M80 10 c34 30 40 90 26 150 h-52 c-14 -60 -8 -120 26 -150 z" fill="#f2f2f2" stroke="#000" strokeWidth="4" />
        <circle cx="80" cy="80" r="16" fill="#34eadd" stroke="#000" strokeWidth="4" />
        <path d="M54 130 l-26 40 h30 M106 130 l26 40 h-30" fill="#ff4f81" stroke="#000" strokeWidth="4" strokeLinejoin="round" />
        <path className="flame" d="M62 162 c0 30 18 46 18 66 c0 -20 18 -36 18 -66 z" fill="#ffd527" stroke="#000" strokeWidth="3" />
      </g>
    </svg>
  );
}

export function Services() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <section id="services" className="relative bg-black text-white overflow-hidden">
      <Streaks density={50} />
      <div className="relative mx-auto max-w-6xl px-5 sm:px-8 pt-24 sm:pt-32 pb-16 text-center">
        <motion.h2 initial={{ opacity: 0, scale: 0.92 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
          className="display text-[clamp(48px,8vw,108px)]">I solve<br />software<br />problems</motion.h2>
        <p className="serif-i text-lg sm:text-xl mt-5">I offer building, testing and shipping across:</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3 sm:gap-4 max-w-3xl mx-auto">
          {SERVICES.map((s, i) => {
            const { I, color } = SV[i];
            return (
              <motion.span key={s.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 * i }}>
                <Key color={color as any} onClick={() => setOpen(i)}><span className="text-lg sm:text-xl">{s.title}</span><I className="w-5 h-5" /></Key>
              </motion.span>
            );
          })}
        </div>
      </div>
      <div className="relative h-[180px] sm:h-[240px] mx-auto max-w-6xl">
        <div className="absolute left-2 sm:left-10 bottom-0 w-[150px] sm:w-[220px] h-full"><BugArt /></div>
        <div className="absolute right-4 sm:right-16 bottom-0 w-[90px] sm:w-[130px] h-full"><RocketArt /></div>
        <svg viewBox="0 0 1200 60" preserveAspectRatio="none" className="absolute bottom-0 inset-x-0 w-full h-10"><path d="M0 60 C200 10 380 40 600 26 S1000 6 1200 30 V60Z" fill="#3c3b3f" stroke="#000" strokeWidth="3" /></svg>
      </div>

      <AnimatePresence>
        {open !== null && (
          <motion.div className="fixed inset-0 z-[80] bg-black/70 grid place-items-center p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(null)}>
            <motion.div initial={{ y: 40, rotate: -2, opacity: 0 }} animate={{ y: 0, rotate: 0, opacity: 1 }} exit={{ y: 30, opacity: 0 }}
              onClick={(e) => e.stopPropagation()} className="w-full max-w-lg bg-white text-black rounded-[22px] border-2 border-black p-6 sm:p-8 text-left relative">
              <div className="absolute top-4 right-4"><Key icon sm onClick={() => setOpen(null)} title="Close"><X className="w-4 h-4" /></Key></div>
              <div className="display text-4xl pr-12">{SERVICES[open].title}</div>
              <ul className="mt-5 space-y-2">
                {SERVICES[open].points.map((p) => <li key={p} className="flex gap-2 font-serif"><Check className="w-5 h-5 shrink-0 text-[#0e9f94]" />{p}</li>)}
              </ul>
              <div className="mt-5 flex flex-wrap gap-2">
                {SKILLS.filter((s) => (SV[open].skills as readonly string[]).includes(s.name)).map((s) => (
                  <span key={s.name} className="inline-flex items-center gap-1.5 border-2 border-black rounded-full px-3 py-1 text-sm font-bold"><BrandIcon name={s.icon} size={14} color={s.color} />{s.name}</span>
                ))}
              </div>
              <div className="mt-6 flex flex-wrap gap-2">
                <Key color="teal" sm href={gmailCompose(`Project inquiry — ${SERVICES[open].title}`)}>Email me</Key>
                <Key color="green" sm href={waLink(`Hi Ahmed, I need help with ${SERVICES[open].title}.`)}>WhatsApp</Key>
                <Key color="yellow" sm onClick={() => { const t = SERVICES[open!].title; setOpen(null); openChat(`What can Ahmed do in ${t}?`); }}>Ask AI</Key>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

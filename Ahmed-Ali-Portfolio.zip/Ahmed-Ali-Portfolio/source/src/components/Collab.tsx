import { FormEvent, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Send, Mail, Github, Linkedin, MapPin, Copy, Check, Phone } from 'lucide-react';
import { Key, Logo } from './kit';
import { Streaks } from './Intro';
import Globe from './Globe';
import { PROFILE, gmailCompose, waLink } from '../data';
import { BrandIcon } from '../lib/ui';

function Mug() {
  return (
    <svg viewBox="0 0 120 170" className="w-full" aria-hidden>
      {[0, 1, 2].map((k) => <path key={k} className="flame" style={{ animationDelay: `${k * 0.3}s` }} d={`M${42 + k * 16} 60 c-8 -14 8 -20 0 -36 c-6 -10 4 -16 2 -22`} stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" opacity=".7" />)}
      <path d="M20 70 h70 v70 c0 14 -10 22 -22 22 h-26 c-12 0 -22 -8 -22 -22 z" fill="#ff4f81" stroke="#000" strokeWidth="4" />
      <path d="M90 86 c22 0 22 36 0 36" fill="none" stroke="#000" strokeWidth="10" /><path d="M90 86 c22 0 22 36 0 36" fill="none" stroke="#ff4f81" strokeWidth="4" />
      <text x="55" y="120" textAnchor="middle" fontFamily="monospace" fontWeight="700" fontSize="16">{'{ }'}</text>
    </svg>
  );
}
function Plant() {
  return (
    <svg viewBox="0 0 120 190" className="w-full" aria-hidden>
      <g className="bob" style={{ transformOrigin: '60px 120px' }}>
        <path d="M60 120 C30 100 18 60 30 30 C52 52 62 86 60 120 Z" fill="#34eadd" stroke="#000" strokeWidth="4" />
        <path d="M60 120 C90 96 104 64 92 36 C70 58 58 90 60 120 Z" fill="#36d07e" stroke="#000" strokeWidth="4" />
        <path d="M60 120 C56 90 60 50 60 14" stroke="#000" strokeWidth="4" fill="none" />
      </g>
      <path d="M26 120 h68 l-8 60 h-52 z" fill="#ffd527" stroke="#000" strokeWidth="4" strokeLinejoin="round" />
    </svg>
  );
}

function PKTClock() {
  const [t, setT] = useState(() => new Date());
  useEffect(() => { const i = setInterval(() => setT(new Date()), 1000); return () => clearInterval(i); }, []);
  const time = t.toLocaleTimeString('en-GB', { timeZone: PROFILE.timezone, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const h = Number(t.toLocaleString('en-GB', { timeZone: PROFILE.timezone, hour: '2-digit', hour12: false }));
  const awake = h >= 9 && h < 23;
  return (
    <div className="font-serif text-sm">
      <div className="display text-3xl tabular-nums">{time} <span className="text-base text-white/60">PKT</span></div>
      <div className="flex items-center gap-2 text-white/75 mt-1"><span className={`w-2 h-2 rounded-full ${awake ? 'bg-[#1fd16b] animate-pulse' : 'bg-white/40'}`} />{awake ? 'Ahmed is likely online now' : 'Night in Pakistan — replies next morning'}</div>
    </div>
  );
}

export function Collab() {
  const [f, setF] = useState({ name: '', email: '', company: '', msg: '' });
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState('');
  const body = `Hi Ahmed,\n\n${f.msg}\n\n— ${f.name}${f.company ? ` (${f.company})` : ''}\n${f.email}`;
  const subject = `Portfolio inquiry from ${f.name || 'a visitor'}`;
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!f.name.trim() || !/^\S+@\S+\.\S+$/.test(f.email) || f.msg.trim().length < 5) { setErr('Please add your name, a valid email and a short message.'); return; }
    setErr(''); setSent(true);
  };
  const input = 'w-full bg-[#2b2a2d] border-2 border-[#4a494d] rounded-lg px-3 py-2.5 text-white placeholder:text-white/45 font-serif text-[15px] focus:outline-none focus:border-yellow';

  return (
    <section id="contact" className="relative bg-coal text-white overflow-hidden">
      <Streaks density={45} />
      <div className="relative mx-auto max-w-6xl px-5 sm:px-8 pt-24 sm:pt-28 pb-10">
        <h2 className="display text-center text-[clamp(52px,9vw,120px)] text-yellow">Let's<br className="sm:hidden" /> collaborate</h2>
        <p className="serif-i text-center text-lg mt-2">Fine. Let's build it — tell me about your project.</p>

        <div className="relative mt-12 mx-auto max-w-[680px]">
          <div className="hidden md:block absolute -left-44 bottom-24 w-28"><Mug /></div>
          <div className="hidden md:block absolute -right-44 bottom-24 w-28"><Plant /></div>
          {/* monitor */}
          <motion.div initial={{ y: 40, opacity: 0 }} whileInView={{ y: 0, opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.7 }}
            className="rounded-[28px] border-4 border-black bg-[#3c3b3f] p-4 sm:p-6 shadow-[0_10px_0_#000]">
            <div className="relative rounded-[18px] border-4 border-black bg-[#131212] p-4 sm:p-6 overflow-hidden">
              <div className="pointer-events-none absolute inset-0 opacity-[0.07]" style={{ backgroundImage: 'repeating-linear-gradient(0deg,#fff 0 1px,transparent 1px 3px)' }} />
              <AnimatePresence mode="wait">
                {!sent ? (
                  <motion.form key="f" onSubmit={submit} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative space-y-3" noValidate>
                    <div className="font-mono text-xs text-teal">ahmed@portfolio:~$ <span className="caret">new message</span></div>
                    <div className="grid sm:grid-cols-2 gap-3">
                      <input className={input} placeholder="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Name" />
                      <input className={input} placeholder="Email" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} aria-label="Email" />
                    </div>
                    <input className={input} placeholder="Company / Project (optional)" value={f.company} onChange={(e) => setF({ ...f, company: e.target.value })} aria-label="Company" />
                    <textarea className={input + ' min-h-[110px] resize-y'} placeholder="Your message" value={f.msg} onChange={(e) => setF({ ...f, msg: e.target.value })} aria-label="Message" />
                    {err && <div className="text-pink text-sm font-serif">{err}</div>}
                    <div className="flex justify-center pt-1"><Key color="white" serif type="submit"><span className="text-[16px]">Submit</span><Send className="w-4 h-4" /></Key></div>
                  </motion.form>
                ) : (
                  <motion.div key="s" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="relative text-center py-6">
                    <div className="display text-3xl text-yellow">Message ready, {f.name.split(' ')[0]}!</div>
                    <p className="font-serif text-white/80 mt-2">Pick how to send it — it opens pre-filled:</p>
                    <div className="mt-5 flex flex-wrap justify-center gap-3">
                      <Key color="teal" href={gmailCompose(subject, body)}><Mail className="w-4 h-4" /> Send via Gmail</Key>
                      <Key color="green" href={waLink(body)}><BrandIcon name="whatsapp" size={16} /> Send via WhatsApp</Key>
                    </div>
                    <button onClick={() => setSent(false)} className="mt-5 text-sm underline font-serif text-white/70 hover:text-white">Edit message</button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <div className="mt-3 flex justify-between items-center px-2"><span className="w-16 h-2 rounded bg-black/40" /><span className="w-3 h-3 rounded-full bg-[#1fd16b] border-2 border-black" /></div>
          </motion.div>
          <div className="mx-auto w-28 h-10 bg-[#2b2a2d] border-x-4 border-black" />
          {/* keyboard */}
          <div className="mx-auto max-w-[620px] rounded-[18px] border-4 border-black bg-[#3c3b3f] p-3 grid grid-cols-[repeat(14,1fr)] gap-1.5 shadow-[0_8px_0_#000]">
            {Array.from({ length: 39 }).map((_, k) => (
              <span key={k} className={`h-5 sm:h-6 rounded-[5px] border-2 border-black ${k === 30 ? 'col-span-4' : ''} ${[2, 9, 17].includes(k) ? 'bg-yellow' : [5, 22].includes(k) ? 'bg-teal' : k === 12 ? 'bg-pink' : 'bg-[#e9e9e9]'} hover:translate-y-[2px] transition`} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  const [copied, setCopied] = useState('');
  const copy = (t: string) => { navigator.clipboard?.writeText(t).then(() => { setCopied(t); setTimeout(() => setCopied(''), 1400); }).catch(() => {}); };
  const link = 'font-serif text-[15px] text-white/85 hover:text-yellow transition';
  return (
    <footer className="bg-black text-white">
      <div className="mx-auto max-w-6xl px-5 sm:px-8 py-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.1fr_.8fr_.8fr_1.2fr_1.2fr]">
        <div>
          <Logo />
          <div className="font-serif text-sm mt-4">© {PROFILE.fullName}, {new Date().getFullYear()}</div>
          <div className="display text-sm mt-6">Credits</div>
          <div className="font-serif text-sm text-white/60 mt-1">Portfolio of Ahmed Ali.<br />Illustrations: original SVG.</div>
        </div>
        <div>
          <div className="display text-sm mb-3">My socials</div>
          <div className="space-y-2">
            <a className={`${link} flex items-center gap-2`} href={PROFILE.github} target="_blank" rel="noopener noreferrer"><Github className="w-4 h-4" />GitHub</a>
            <a className={`${link} flex items-center gap-2`} href={PROFILE.linkedin} target="_blank" rel="noopener noreferrer"><Linkedin className="w-4 h-4" />LinkedIn</a>
            <a className={`${link} flex items-center gap-2`} href={waLink('Hi Ahmed!')} target="_blank" rel="noopener noreferrer"><BrandIcon name="whatsapp" size={15} />WhatsApp</a>
            <a className={`${link} flex items-center gap-2`} href={gmailCompose()} target="_blank" rel="noopener noreferrer"><Mail className="w-4 h-4" />Gmail</a>
          </div>
        </div>
        <div>
          <div className="display text-sm mb-3">Links</div>
          <div className="grid gap-1.5">
            {[['Home', '#top'], ['Work', '#work'], ['Services', '#services'], ['Toolkit', '#toolkit'], ['Education', '#education'], ['Writing', '#writing'], ['CareBox Lab', '#carebox-lab'], ['HeavyEquip Lab', '#heavyequip-lab'], ["Let's collaborate", '#contact']].map(([a, b]) => <a key={a} className={link} href={b}>{a}</a>)}
          </div>
        </div>
        <div>
          <div className="display text-sm mb-3">Email</div>
          <div className="flex items-center gap-2">
            <a className={`${link} underline break-all`} href={gmailCompose()} target="_blank" rel="noopener noreferrer">{PROFILE.email}</a>
            <button onClick={() => copy(PROFILE.email)} title="Copy email" className="shrink-0 text-white/60 hover:text-yellow">{copied === PROFILE.email ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}</button>
          </div>
          <div className="display text-sm mt-6 mb-2">Call / WhatsApp</div>
          <div className="flex items-center gap-2">
            <a className={`${link} flex items-center gap-2`} href={`tel:${PROFILE.phoneIntl.replace(/\s/g, '')}`}><Phone className="w-4 h-4" />{PROFILE.phoneIntl}</a>
            <button onClick={() => copy(PROFILE.phoneIntl)} title="Copy number" className="text-white/60 hover:text-yellow">{copied === PROFILE.phoneIntl ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}</button>
          </div>
          <div className="display text-sm mt-6 mb-2">Visit</div>
          <div className="font-serif text-[15px] text-white/85">{PROFILE.location}</div>
          <a className="mt-2 inline-flex items-center gap-2 underline font-serif text-[15px] hover:text-yellow" target="_blank" rel="noopener noreferrer"
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(PROFILE.location)}`}><MapPin className="w-4 h-4" />Find directions</a>
        </div>
        <div>
          <Globe />
          <div className="mt-3"><PKTClock /></div>
        </div>
      </div>
    </footer>
  );
}

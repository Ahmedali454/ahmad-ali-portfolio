import { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Burst } from './kit';
import { ABOUT_POINTS, PROFILE, STATS } from '../data';
import { useCountUp } from '../lib/ui';

const BG = ['#a8f5ee', '#ffd527', '#ffb3c8', '#a8f5ee'];

function Art({ i }: { i: number }) {
  const S = { stroke: '#000', strokeWidth: 4, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const };
  if (i === 0) return (
    <svg viewBox="0 0 200 160" className="w-full h-full">
      <rect x="40" y="30" width="120" height="78" rx="8" fill="#fff" {...S} />
      <rect x="50" y="40" width="100" height="58" fill="#131212" />
      {[0, 1, 2, 3].map((k) => <rect key={k} x={58} y={48 + k * 12} width={[60, 80, 44, 70][k]} height="6" rx="3" fill={['#34eadd', '#ffd527', '#ff4f81', '#fff'][k]} />)}
      <path d="M28 108 h144 l14 22 H14 z" fill="#ececec" {...S} />
    </svg>
  );
  if (i === 1) return (
    <svg viewBox="0 0 200 160" className="w-full h-full">
      {[['PL/SQL', 30, 74, '#34eadd'], ['SQL', 104, 74, '#ffd527'], ['APEX', 66, 20, '#ff4f81']].map(([t, x, y, c]) => (
        <g key={t as string} transform={`translate(${x},${y})`}>
          <rect width="68" height="58" rx="12" fill="#555" {...S} />
          <rect x="5" y="3" width="58" height="42" rx="9" fill={c as string} stroke="#000" strokeWidth="2.5" />
          <text x="34" y="30" textAnchor="middle" fontFamily="Oswald, Arial" fontWeight="700" fontSize="15">{t}</text>
        </g>
      ))}
    </svg>
  );
  if (i === 2) return (
    <svg viewBox="0 0 200 160" className="w-full h-full">
      <rect x="30" y="24" width="140" height="108" rx="10" fill="#fff" {...S} />
      <path d="M30 46 h140" {...S} fill="none" />
      {[0, 1, 2].map((k) => <circle key={k} cx={44 + k * 12} cy="35" r="4" fill={['#ff4f81', '#ffd527', '#34eadd'][k]} stroke="#000" strokeWidth="2" />)}
      <circle cx="100" cy="88" r="30" fill="#34eadd" {...S} />
      <path d="M70 88 h60 M100 58 c-16 18 -16 42 0 60 M100 58 c16 18 16 42 0 60" fill="none" {...S} strokeWidth="3" />
    </svg>
  );
  return (
    <svg viewBox="0 0 200 160" className="w-full h-full">
      <path d="M100 30 L180 62 L100 94 L20 62 Z" fill="#131212" {...S} stroke="#fff" />
      <path d="M56 78 v30 c0 14 88 14 88 0 v-30" fill="#131212" {...S} stroke="#fff" />
      <path d="M170 66 v40" stroke="#ffd527" strokeWidth="4" strokeLinecap="round" />
      <circle cx="170" cy="110" r="7" fill="#ffd527" stroke="#000" strokeWidth="2" />
    </svg>
  );
}

function StatCard({ i, onSeen }: { i: number; onSeen: (i: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [seen, setSeen] = useState(false);
  const s = STATS[i];
  const v = useCountUp(s.value, seen);
  useEffect(() => {
    const el = ref.current!; const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setSeen(true); onSeen(i); } }, { rootMargin: '-45% 0px -45% 0px' });
    io.observe(el); return () => io.disconnect();
  }, [i, onSeen]);
  return (
    <motion.div ref={ref} whileHover={{ rotate: i % 2 ? 1.5 : -1.5, y: -6 }}
      className="bg-black text-white rounded-[22px] border-2 border-black p-6 sm:p-8 aspect-[1/1.02] flex flex-col">
      <div className="relative flex-1 grid place-items-center">
        <Burst color={['#34eadd', '#ffd527', '#ff4f81', '#34eadd'][i]} className="absolute w-[62%] h-[62%]" points={16} />
        <div className="relative w-[78%] h-[78%]"><Art i={i} /></div>
      </div>
      <div className="display text-center text-4xl sm:text-5xl mt-3">{v}{s.suffix} {s.label}</div>
    </motion.div>
  );
}

export function Believe() {
  const [bg, setBg] = useState(0);
  return (
    <section className="transition-colors duration-700 text-black" style={{ background: BG[bg] }}>
      <div className="mx-auto max-w-6xl px-5 sm:px-8 py-20 sm:py-28 grid md:grid-cols-2 gap-10 md:gap-14">
        <div className="md:sticky md:top-24 self-start">
          <h2 className="display text-[clamp(48px,7vw,96px)]">I believe in clean, tested software</h2>
          <p className="serif-i text-lg mt-6 max-w-md">Every project gets the same treatment: build it fast, test it hard, ship it working.</p>
          <ul className="mt-6 space-y-2 max-w-md">
            {ABOUT_POINTS.map((p) => (
              <li key={p} className="flex gap-3 font-serif text-[15px] leading-snug"><span className="mt-1.5 w-2.5 h-2.5 shrink-0 rotate-45 bg-black" />{p}</li>
            ))}
          </ul>
          <div className="mt-6 inline-flex items-center gap-2 bg-black text-white rounded-full px-4 py-2 font-serif text-sm">
            <span className="w-2 h-2 rounded-full bg-[#1fd16b] animate-pulse" /> {PROFILE.location}
          </div>
        </div>
        <div className="space-y-8">
          {STATS.map((_, i) => <StatCard key={i} i={i} onSeen={setBg} />)}
        </div>
      </div>
    </section>
  );
}

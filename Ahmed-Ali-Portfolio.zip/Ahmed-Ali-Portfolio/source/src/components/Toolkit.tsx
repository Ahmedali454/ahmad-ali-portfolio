import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Shuffle } from 'lucide-react';
import { Key } from './kit';
import { SKILLS, type SkillCat } from '../data';
import { BrandIcon } from '../lib/ui';

const CATS: ('All' | SkillCat)[] = ['All', 'Database', 'Oracle APEX', 'API & Integration', 'Web / Front-End', 'App Development', 'Languages'];
const CC = ['pink', 'white', 'teal', 'yellow', 'dark', 'white', 'teal', 'yellow'] as const;

export function Toolkit() {
  const [cat, setCat] = useState<(typeof CATS)[number]>('All');
  const [seed, setSeed] = useState(0);
  const [flip, setFlip] = useState<string | null>(null);
  const list = useMemo(() => {
    const l = SKILLS.filter((s) => cat === 'All' || s.cat === cat);
    if (!seed) return l;
    const a = [...l]; let r = seed;
    for (let i = a.length - 1; i > 0; i--) { r = (r * 9301 + 49297) % 233280; const j = Math.floor((r / 233280) * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }, [cat, seed]);

  return (
    <section id="toolkit" className="bg-paper text-ink py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <h2 className="display text-center text-[clamp(56px,9vw,120px)] text-[#0e9f94] dark:text-teal">Toolkit</h2>
        <p className="serif-i text-center text-lg mt-2">Tap a key to see what I do with it.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-2.5">
          {CATS.map((c, i) => (
            <Key key={c} sm serif color={CC[i] as any} active={cat === c} onClick={() => { setCat(c); setFlip(null); }}>
              <span className="text-[15px]">{c}</span>
            </Key>
          ))}
          <Key sm color="black" onClick={() => setSeed((s) => s + 7)} title="Shuffle"><Shuffle className="w-4 h-4" /></Key>
        </div>

        <motion.div layout className="mt-10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
          <AnimatePresence mode="popLayout">
            {list.map((s) => {
              const on = flip === s.name;
              return (
                <motion.button layout key={s.name} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 26 }}
                  onClick={() => setFlip(on ? null : s.name)}
                  className="group relative text-left rounded-[20px] border-2 border-black pb-[10px] focus-visible:outline-3 focus-visible:outline-yellow"
                  style={{ background: on ? '#1b1a1c' : '#a7a7a7' }} aria-pressed={on}>
                  <div className={`rounded-[16px] m-[2px] mb-0 p-4 sm:p-5 min-h-[150px] flex flex-col transition-transform duration-150 group-hover:translate-y-[2px] group-active:translate-y-[7px] ${on ? 'bg-black text-white' : 'bg-white text-black'}`}>
                    <div className="flex items-start justify-between gap-2">
                      <span className="w-11 h-11 rounded-xl border-2 border-black grid place-items-center" style={{ background: s.color + '26' }}>
                        <BrandIcon name={s.icon} size={24} color={s.icon === 'github' ? (on ? '#fff' : '#000') : s.color} />
                      </span>
                      <span className="font-serif italic text-[11px] sm:text-xs text-right leading-tight opacity-60 max-w-[55%]">{s.cat}</span>
                    </div>
                    <div className="display text-[17px] sm:text-2xl mt-3 leading-tight break-words">{s.name}</div>
                    <div className="mt-auto pt-3">
                      {on ? <div className="font-serif italic text-sm text-yellow">{s.note}</div>
                        : <div className="h-2 rounded-full overflow-hidden border border-black/20" style={{ background: s.color }} />}
                    </div>
                  </div>
                </motion.button>
              );
            })}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}

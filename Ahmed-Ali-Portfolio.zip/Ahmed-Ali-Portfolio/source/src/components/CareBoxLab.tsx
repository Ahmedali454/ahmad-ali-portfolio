import { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowLeft, LayoutDashboard, Users, PackagePlus, PenLine, RefreshCw, RotateCcw, Search, Plus, Minus, Check, AlertTriangle, Lock, KeyRound, Send, Eraser } from 'lucide-react';
import { Key } from './kit';

/* ---------------- types & seed ---------------- */
type CStatus = 'Active' | 'Inactive' | 'Paused' | 'Deleted';
type Stage = 'Draft' | 'Approved' | 'Signed' | 'Applied';
type Customer = { id: string; name: string; phone: string; city: string; status: CStatus; created: string; source: 'APEX' | 'API' };
type Line = { product: string; qty: number };
type Order = { id: string; custId: string; lines: Line[]; created: string; stage: Stage; signature?: string };
type Log = { ts: string; text: string };
type DB = { customers: Customer[]; orders: Order[]; log: Log[]; seq: number; synced: number };

const PRODUCTS = [
  { name: 'Disposable gloves', unit: 'box', max: 4 },
  { name: 'Hand sanitizer', unit: '500 ml', max: 3 },
  { name: 'Surface disinfectant', unit: '1 L', max: 2 },
  { name: 'Face masks', unit: 'box', max: 4 },
  { name: 'Bed protectors', unit: 'pack', max: 3 },
  { name: 'Disposable aprons', unit: 'pack', max: 2 },
];
const STATUS_C: Record<CStatus, string> = { Active: '#36d07e', Inactive: '#a7a7a7', Paused: '#ffd527', Deleted: '#ff4f81' };
const STAGE_C: Record<Stage, string> = { Draft: '#ffffff', Approved: '#34eadd', Signed: '#ffd527', Applied: '#36d07e' };
const KEY = 'aa-carebox-v1';

const pad = (n: number) => String(n).padStart(2, '0');
const ymd = (t: Date) => `${t.getFullYear()}-${pad(t.getMonth() + 1)}-${pad(t.getDate())}`;
const ago = (days: number) => { const t = new Date(); t.setDate(t.getDate() - days); return ymd(t); };
const now = () => new Date().toISOString();
const monthKey = (s: string) => s.slice(0, 7);
const addMonths = (d: Date, m: number) => new Date(d.getFullYear(), d.getMonth() + m, 1);

function seed(): DB {
  const names: [string, string, CStatus, number][] = [
    ['Ayesha Khan', 'Islamabad', 'Active', 3], ['Bilal Ahmed', 'Rawalpindi', 'Active', 12], ['Sana Iqbal', 'Hassan Abdal', 'Paused', 40],
    ['Usama Tariq', 'Taxila', 'Active', 55], ['Hira Saleem', 'Attock', 'Inactive', 80], ['Zain Malik', 'Wah Cantt', 'Active', 20],
    ['Maryam Shah', 'Haripur', 'Active', 95], ['Faisal Raza', 'Islamabad', 'Deleted', 120], ['Noor Fatima', 'Rawalpindi', 'Active', 7],
  ];
  const customers: Customer[] = names.map(([name, city, status, d], i) => ({
    id: `C-${1001 + i}`, name, city, status, created: ago(d), phone: `03${(10 + i * 7) % 50 + 10}-${String(4512387 + i * 91873).slice(0, 7)}`, source: 'APEX',
  }));
  const o = (i: number, c: number, d: number, stage: Stage, l: number[]): Order => ({
    id: `CB-${5001 + i}`, custId: customers[c].id, created: ago(d), stage,
    lines: l.map((q, k) => ({ product: PRODUCTS[k].name, qty: q })).filter((x) => x.qty > 0),
  });
  const orders = [
    o(0, 0, 2, 'Draft', [2, 1, 0, 2, 0, 1]), o(1, 1, 5, 'Approved', [1, 1, 1, 1, 1, 0]), o(2, 5, 9, 'Signed', [2, 0, 1, 2, 1, 1]),
    o(3, 8, 14, 'Applied', [1, 2, 0, 1, 0, 0]), o(4, 0, 33, 'Applied', [2, 1, 1, 2, 1, 1]), o(5, 3, 38, 'Applied', [1, 1, 0, 1, 0, 0]),
    o(6, 6, 47, 'Applied', [3, 1, 1, 2, 0, 1]), o(7, 1, 63, 'Applied', [1, 0, 1, 1, 1, 0]), o(8, 2, 70, 'Applied', [2, 1, 0, 0, 2, 0]),
    o(9, 6, 88, 'Applied', [1, 1, 1, 1, 0, 0]), o(10, 3, 101, 'Applied', [2, 2, 1, 2, 1, 1]),
  ];
  return { customers, orders, seq: 5012, synced: 0, log: [{ ts: now(), text: 'Demo data loaded' }] };
}
function load(): DB { try { const s = localStorage.getItem(KEY); if (s) return JSON.parse(s); } catch { /* ignore */ } return seed(); }

/* ---------------- small UI ---------------- */
const Card = ({ children, className = '' }: { children: React.ReactNode; className?: string }) =>
  <div className={`rounded-2xl border-2 border-black bg-white text-black ${className}`}>{children}</div>;
const Chip = ({ c, children }: { c: string; children: React.ReactNode }) =>
  <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border-2 border-black whitespace-nowrap" style={{ background: c }}>{children}</span>;
const H = ({ children, sub }: { children: React.ReactNode; sub?: string }) =>
  <div className="mb-4"><div className="display text-3xl dark:text-white">{children}</div>{sub && <div className="font-serif italic text-sm text-black/60 dark:text-white/60">{sub}</div>}</div>;
const input = 'w-full rounded-xl border-2 border-black px-3 py-2 font-serif bg-white text-black outline-none focus:ring-4 focus:ring-yellow/60';
const qtyOf = (o: Order) => o.lines.reduce((a, l) => a + l.qty, 0);

/* ---------------- Dashboard ---------------- */
function Dashboard({ db }: { db: DB }) {
  const t = new Date();
  const cur = monthKey(ymd(t)), prev = monthKey(ymd(addMonths(t, -1)));
  const last3 = [0, -1, -2].map((m) => monthKey(ymd(addMonths(t, m))));
  const cnt = (list: { created: string }[], keys: string[]) => list.filter((x) => keys.includes(monthKey(x.created))).length;
  const live = db.customers.filter((c) => c.status !== 'Deleted');
  const periods = [
    { l: 'Current month', c: cnt(live, [cur]), b: cnt(db.orders, [cur]) },
    { l: 'Previous month', c: cnt(live, [prev]), b: cnt(db.orders, [prev]) },
    { l: 'Last 3 months', c: cnt(live, last3), b: cnt(db.orders, last3) },
  ];
  const months = [-5, -4, -3, -2, -1, 0].map((m) => { const d = addMonths(t, m); return { k: monthKey(ymd(d)), l: d.toLocaleString('en', { month: 'short' }) }; });
  const perMonth = months.map((m) => ({ ...m, v: db.orders.filter((o) => monthKey(o.created) === m.k).length }));
  const max = Math.max(1, ...perMonth.map((m) => m.v));
  const byStage = (['Draft', 'Approved', 'Signed', 'Applied'] as Stage[]).map((s) => ({ s, v: db.orders.filter((o) => o.stage === s).length }));
  const byStatus = (['Active', 'Inactive', 'Paused', 'Deleted'] as CStatus[]).map((s) => ({ s, v: db.customers.filter((c) => c.status === s).length }));
  return (
    <div className="grid gap-5">
      <div className="grid sm:grid-cols-3 gap-4">
        {periods.map((p, i) => (
          <Card key={p.l} className="p-5 relative overflow-hidden">
            <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full border-2 border-black" style={{ background: ['#34eadd', '#ffd527', '#ff4f81'][i] }} />
            <div className="serif-i text-sm text-black/60">{p.l}</div>
            <div className="flex gap-6 mt-2">
              <div><div className="display text-5xl">{p.b}</div><div className="font-serif text-xs">CareBoxes</div></div>
              <div><div className="display text-5xl">{p.c}</div><div className="font-serif text-xs">New customers</div></div>
            </div>
          </Card>
        ))}
      </div>
      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <div className="display text-xl">CareBoxes per month</div>
          <div className="mt-4 h-48 flex items-end gap-3">
            {perMonth.map((m) => (
              <div key={m.k} className="flex-1 flex flex-col items-center gap-1">
                <div className="font-bold text-sm">{m.v}</div>
                <motion.div initial={{ height: 0 }} animate={{ height: `${(m.v / max) * 140 + 4}px` }} transition={{ duration: 0.7 }}
                  className="w-full rounded-t-lg border-2 border-black" style={{ background: m.k === months[5].k ? '#ffd527' : '#34eadd' }} />
                <div className="font-serif text-xs">{m.l}</div>
              </div>
            ))}
          </div>
        </Card>
        <Card className="p-5">
          <div className="display text-xl">Customer status</div>
          <div className="mt-4 h-5 flex rounded-full overflow-hidden border-2 border-black">
            {byStatus.map((x) => x.v > 0 && <div key={x.s} style={{ flex: x.v, background: STATUS_C[x.s] }} title={`${x.s}: ${x.v}`} />)}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {byStatus.map((x) => <div key={x.s} className="flex items-center justify-between rounded-xl border-2 border-black px-3 py-2"><Chip c={STATUS_C[x.s]}>{x.s}</Chip><b className="display text-xl">{x.v}</b></div>)}
          </div>
          <div className="display text-xl mt-5">Order pipeline</div>
          <div className="mt-2 grid grid-cols-4 gap-1.5 text-center">
            {byStage.map((x) => <div key={x.s} className="rounded-xl border-2 border-black py-2" style={{ background: STAGE_C[x.s] }}><div className="display text-2xl">{x.v}</div><div className="text-[10px] font-bold uppercase">{x.s}</div></div>)}
          </div>
        </Card>
      </div>
      <Card className="p-5">
        <div className="display text-xl">Activity</div>
        <ul className="mt-2 divide-y divide-black/10 font-serif text-sm max-h-56 overflow-auto">
          {db.log.slice(0, 12).map((l, i) => <li key={i} className="py-2 flex justify-between gap-3"><span>{l.text}</span><span className="text-black/50 whitespace-nowrap">{new Date(l.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></li>)}
        </ul>
      </Card>
    </div>
  );
}

/* ---------------- Customers (interactive report) ---------------- */
function Customers({ db, set, log, go }: Props & { go: (custId: string) => void }) {
  const [q, setQ] = useState(''); const [st, setSt] = useState<'All' | CStatus>('All');
  const [f, setF] = useState({ name: '', phone: '', city: '' }); const [err, setErr] = useState<Record<string, string>>({});
  const rows = db.customers.filter((c) => (st === 'All' || c.status === st) && (c.name + c.id + c.city + c.phone).toLowerCase().includes(q.toLowerCase()));
  const add = () => {
    const e: Record<string, string> = {};
    if (f.name.trim().length < 3) e.name = 'Name must have at least 3 letters';
    if (!/^03\d{2}-?\d{7}$/.test(f.phone.trim())) e.phone = 'Format: 03XX-XXXXXXX';
    if (db.customers.some((c) => c.phone.replace('-', '') === f.phone.trim().replace('-', ''))) e.phone = 'This phone number already exists';
    if (!f.city.trim()) e.city = 'City is required';
    setErr(e); if (Object.keys(e).length) return;
    const p = f.phone.trim().replace('-', '');
    const c: Customer = { id: `C-${1001 + db.customers.length}`, name: f.name.trim(), phone: `${p.slice(0, 4)}-${p.slice(4)}`, city: f.city.trim(), status: 'Active', created: ymd(new Date()), source: 'APEX' };
    set((d) => ({ ...d, customers: [c, ...d.customers] })); log(`Customer ${c.id} ${c.name} created`); setF({ name: '', phone: '', city: '' });
  };
  const setStatus = (c: Customer, s: CStatus) => { set((d) => ({ ...d, customers: d.customers.map((x) => x.id === c.id ? { ...x, status: s } : x) })); log(`${c.id} status → ${s}`); };
  return (
    <div className="grid lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2">
        <H sub="Search, filter and change status. The status decides what the customer can do.">Customers</H>
        <div className="flex flex-wrap gap-2 mb-3">
          <div className="relative flex-1 min-w-[200px]"><Search className="w-4 h-4 absolute left-3 top-3 text-black/50" /><input className={input + ' pl-9'} placeholder="Search name, ID, city…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <select className={input + ' !w-auto'} value={st} onChange={(e) => setSt(e.target.value as any)}>{['All', 'Active', 'Inactive', 'Paused', 'Deleted'].map((s) => <option key={s}>{s}</option>)}</select>
        </div>
        <Card className="overflow-x-auto">
          <table className="w-full text-sm font-serif min-w-[620px]">
            <thead><tr className="text-left border-b-2 border-black bg-[#f3f3f3]">{['ID', 'Name', 'City', 'Phone', 'Status', ''].map((h) => <th key={h} className="px-3 py-2 font-display uppercase tracking-wide">{h}</th>)}</tr></thead>
            <tbody>
              {rows.map((c) => {
                const ok = c.status === 'Active';
                return (
                  <tr key={c.id} className={`border-b border-black/10 ${c.status === 'Deleted' ? 'opacity-50 line-through decoration-black/30' : ''}`}>
                    <td className="px-3 py-2 font-mono text-xs">{c.id}{c.source === 'API' && <span className="ml-1 text-[9px] bg-[#34eadd] border border-black rounded px-1 no-underline">API</span>}</td>
                    <td className="px-3 py-2 font-bold">{c.name}</td><td className="px-3 py-2">{c.city}</td><td className="px-3 py-2 whitespace-nowrap">{c.phone}</td>
                    <td className="px-3 py-2">
                      <select value={c.status} onChange={(e) => setStatus(c, e.target.value as CStatus)} className="rounded-full border-2 border-black text-[11px] font-bold uppercase px-2 py-0.5" style={{ background: STATUS_C[c.status] }}>
                        {(['Active', 'Inactive', 'Paused', 'Deleted'] as CStatus[]).map((s) => <option key={s}>{s}</option>)}
                      </select>
                    </td>
                    <td className="px-3 py-2 text-right">
                      <button disabled={!ok} onClick={() => go(c.id)} title={ok ? 'Create a CareBox order' : `Not allowed: customer is ${c.status}`}
                        className={`text-xs font-bold rounded-lg border-2 border-black px-2 py-1 whitespace-nowrap ${ok ? 'bg-yellow hover:-translate-y-0.5 transition' : 'bg-black/5 text-black/40 cursor-not-allowed'}`}>
                        {ok ? '+ CareBox' : <span className="inline-flex items-center gap-1"><Lock className="w-3 h-3" />{c.status}</span>}
                      </button>
                    </td>
                  </tr>
                );
              })}
              {!rows.length && <tr><td colSpan={6} className="px-3 py-8 text-center italic">No customers match.</td></tr>}
            </tbody>
          </table>
        </Card>
        <div className="font-serif italic text-xs mt-2 dark:text-white/70">{rows.length} of {db.customers.length} rows · only <b>Active</b> customers can order (server-side condition).</div>
      </div>
      <div>
        <H sub="Validated like an APEX form.">New customer</H>
        <Card className="p-4 grid gap-3">
          {([['name', 'Full name', 'e.g. Ali Hassan'], ['phone', 'Phone', '03XX-XXXXXXX'], ['city', 'City', 'e.g. Hassan Abdal']] as const).map(([k, l, ph]) => (
            <label key={k} className="grid gap-1"><span className="font-display uppercase text-sm">{l}</span>
              <input className={input} placeholder={ph} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
              {err[k] && <span className="text-xs text-[#d6164e] font-bold flex items-center gap-1"><AlertTriangle className="w-3 h-3" />{err[k]}</span>}
            </label>
          ))}
          <Key color="teal" onClick={add}><Plus className="w-4 h-4" /> Create customer</Key>
        </Card>
      </div>
    </div>
  );
}

/* ---------------- New CareBox ---------------- */
function NewOrder({ db, set, log, cust, setCust, done }: Props & { cust: string; setCust: (s: string) => void; done: () => void }) {
  const active = db.customers.filter((c) => c.status === 'Active');
  const [qty, setQty] = useState<number[]>(PRODUCTS.map(() => 0)); const [err, setErr] = useState('');
  const total = qty.reduce((a, b) => a + b, 0);
  const save = () => {
    if (!active.some((c) => c.id === cust)) return setErr('Choose an active customer.');
    if (total < 1) return setErr('Add at least one care product.');
    const id = `CB-${db.seq}`;
    const o: Order = { id, custId: cust, created: ymd(new Date()), stage: 'Draft', lines: qty.map((q, i) => ({ product: PRODUCTS[i].name, qty: q })).filter((l) => l.qty > 0) };
    set((d) => ({ ...d, orders: [o, ...d.orders], seq: d.seq + 1 })); log(`CareBox ${id} created (Draft) for ${cust}`);
    setQty(PRODUCTS.map(() => 0)); setErr(''); done();
  };
  return (
    <div className="grid lg:grid-cols-3 gap-5">
      <div className="lg:col-span-2">
        <H sub="Pick a customer, set quantities. Each product has a maximum per box.">New CareBox order</H>
        <Card className="p-4 mb-4">
          <label className="grid gap-1"><span className="font-display uppercase text-sm">Customer</span>
            <select className={input} value={cust} onChange={(e) => setCust(e.target.value)}>
              <option value="">— Select active customer —</option>
              {active.map((c) => <option key={c.id} value={c.id}>{c.id} · {c.name} ({c.city})</option>)}
            </select>
          </label>
        </Card>
        <div className="grid sm:grid-cols-2 gap-3">
          {PRODUCTS.map((p, i) => (
            <Card key={p.name} className={`p-4 flex items-center gap-3 transition ${qty[i] ? 'shadow-[4px_5px_0_#000] -translate-y-0.5' : ''}`}>
              <div className="w-11 h-11 rounded-xl border-2 border-black grid place-items-center display text-lg" style={{ background: ['#34eadd', '#ffd527', '#ff4f81', '#a8f5ee', '#ffb3c8', '#fff2a8'][i] }}>{i + 1}</div>
              <div className="flex-1"><div className="font-bold">{p.name}</div><div className="font-serif text-xs text-black/60">{p.unit} · max {p.max}</div></div>
              <div className="flex items-center gap-1.5">
                <button className="w-8 h-8 rounded-lg border-2 border-black grid place-items-center disabled:opacity-30" disabled={!qty[i]} onClick={() => setQty(qty.map((v, k) => k === i ? v - 1 : v))} aria-label="Less"><Minus className="w-4 h-4" /></button>
                <span className="display text-2xl w-6 text-center">{qty[i]}</span>
                <button className="w-8 h-8 rounded-lg border-2 border-black grid place-items-center bg-yellow disabled:opacity-30" disabled={qty[i] >= p.max} onClick={() => setQty(qty.map((v, k) => k === i ? v + 1 : v))} aria-label="More"><Plus className="w-4 h-4" /></button>
              </div>
            </Card>
          ))}
        </div>
      </div>
      <div>
        <H sub="Order details">Summary</H>
        <Card className="p-4">
          <div className="font-serif text-sm">{cust ? db.customers.find((c) => c.id === cust)?.name : 'No customer selected'}</div>
          <ul className="mt-3 grid gap-1 font-serif text-sm">
            {qty.map((q, i) => q > 0 && <li key={i} className="flex justify-between"><span>{PRODUCTS[i].name}</span><b>× {q}</b></li>)}
            {!total && <li className="italic text-black/50">Empty box</li>}
          </ul>
          <div className="flex justify-between border-t-2 border-black mt-3 pt-2 display text-xl"><span>Items</span><span>{total}</span></div>
          {err && <div className="mt-3 text-xs text-[#d6164e] font-bold flex items-center gap-1"><AlertTriangle className="w-3 h-3" />{err}</div>}
          <div className="mt-4"><Key color="yellow" onClick={save}><PackagePlus className="w-4 h-4" /> Save as Draft</Key></div>
        </Card>
      </div>
    </div>
  );
}

/* ---------------- Signature pad ---------------- */
function SignPad({ onSave, onCancel }: { onSave: (url: string) => void; onCancel: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null); const drawing = useRef(false); const [inked, setInked] = useState(false);
  useEffect(() => { const c = ref.current!; const x = c.getContext('2d')!; x.lineWidth = 3; x.lineCap = 'round'; x.strokeStyle = '#111'; }, []);
  const pos = (e: React.PointerEvent) => { const r = ref.current!.getBoundingClientRect(); return [(e.clientX - r.left) * (ref.current!.width / r.width), (e.clientY - r.top) * (ref.current!.height / r.height)]; };
  return (
    <div className="grid gap-3">
      <canvas ref={ref} width={560} height={200} className="w-full rounded-xl border-2 border-dashed border-black bg-[#fffdf2] touch-none cursor-crosshair"
        onPointerDown={(e) => { drawing.current = true; const [x, y] = pos(e); const g = ref.current!.getContext('2d')!; g.beginPath(); g.moveTo(x, y); (e.target as Element).setPointerCapture(e.pointerId); }}
        onPointerMove={(e) => { if (!drawing.current) return; const [x, y] = pos(e); const g = ref.current!.getContext('2d')!; g.lineTo(x, y); g.stroke(); setInked(true); }}
        onPointerUp={() => { drawing.current = false; }} />
      <div className="flex flex-wrap gap-2">
        <Key sm color="white" onClick={() => { ref.current!.getContext('2d')!.clearRect(0, 0, 560, 200); setInked(false); }}><Eraser className="w-4 h-4" /> Clear</Key>
        <Key sm color="dark" onClick={onCancel}>Cancel</Key>
        <Key sm color="yellow" onClick={() => inked && onSave(ref.current!.toDataURL())}><PenLine className="w-4 h-4" /> {inked ? 'Save signature' : 'Sign above first'}</Key>
      </div>
    </div>
  );
}

/* ---------------- Approval → Signature → Apply ---------------- */
function Approvals({ db, set, log }: Props) {
  const [signing, setSigning] = useState<string | null>(null); const [f, setF] = useState<'Open' | 'All'>('Open');
  const name = (id: string) => db.customers.find((c) => c.id === id)?.name ?? id;
  const list = db.orders.filter((o) => f === 'All' || o.stage !== 'Applied');
  const move = (o: Order, stage: Stage, extra: Partial<Order> = {}) => { set((d) => ({ ...d, orders: d.orders.map((x) => x.id === o.id ? { ...x, stage, ...extra } : x) })); log(`${o.id} → ${stage}`); };
  return (
    <div>
      <H sub="Draft → Approve → Sign → Apply. Each step unlocks the next; Apply is final.">Approval & signature</H>
      <div className="flex gap-2 mb-4">{(['Open', 'All'] as const).map((k) => <Key key={k} sm serif color={k === 'Open' ? 'teal' : 'white'} active={f === k} onClick={() => setF(k)}>{k === 'Open' ? 'Open orders' : 'All orders'}</Key>)}</div>
      <div className="grid md:grid-cols-2 gap-4">
        {list.map((o) => {
          const steps: Stage[] = ['Draft', 'Approved', 'Signed', 'Applied']; const at = steps.indexOf(o.stage);
          const cust = db.customers.find((c) => c.id === o.custId); const blocked = cust && cust.status !== 'Active' && o.stage !== 'Applied';
          return (
            <Card key={o.id} className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div><div className="display text-2xl">{o.id}</div><div className="font-serif text-sm">{name(o.custId)} · {o.created} · {qtyOf(o)} items</div></div>
                <Chip c={STAGE_C[o.stage]}>{o.stage === 'Applied' && <Check className="w-3 h-3" />}{o.stage}</Chip>
              </div>
              <div className="mt-3 flex items-center gap-1">
                {steps.map((s, i) => <div key={s} className="flex-1 flex flex-col items-center gap-1"><div className="h-2 w-full rounded-full border border-black" style={{ background: i <= at ? STAGE_C[s] === '#ffffff' ? '#000' : STAGE_C[s] : '#eee' }} /><span className="text-[10px] font-bold uppercase">{s}</span></div>)}
              </div>
              <div className="mt-2 font-serif text-xs text-black/60">{o.lines.map((l) => `${l.product} ×${l.qty}`).join(' · ')}</div>
              {o.signature && <img src={o.signature} alt="Customer signature" className="mt-3 h-14 rounded-lg border border-black/20 bg-[#fffdf2]" />}
              {blocked && <div className="mt-3 text-xs font-bold text-[#d6164e] flex items-center gap-1"><Lock className="w-3 h-3" /> Customer is {cust!.status} — workflow locked.</div>}
              {signing === o.id ? (
                <div className="mt-3"><SignPad onCancel={() => setSigning(null)} onSave={(url) => { move(o, 'Signed', { signature: url }); setSigning(null); }} /></div>
              ) : !blocked && o.stage !== 'Applied' && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {o.stage === 'Draft' && <Key sm color="teal" onClick={() => move(o, 'Approved')}><Check className="w-4 h-4" /> Approve</Key>}
                  {o.stage === 'Approved' && <Key sm color="yellow" onClick={() => setSigning(o.id)}><PenLine className="w-4 h-4" /> Sign</Key>}
                  {o.stage === 'Signed' && <Key sm color="green" onClick={() => move(o, 'Applied')}><Send className="w-4 h-4" /> Apply (submit)</Key>}
                </div>
              )}
            </Card>
          );
        })}
        {!list.length && <div className="font-serif italic dark:text-white">No open orders — create one in “New CareBox”.</div>}
      </div>
    </div>
  );
}

/* ---------------- REST API sync + auto-login ---------------- */
const EXTERNAL = [
  { external_id: 'EXT-7781', full_name: 'Kashif Mehmood', phone: '03125550142', city: 'Islamabad', status: 'ACTIVE' },
  { external_id: 'EXT-7782', full_name: 'Rabia Anwar', phone: '03215550178', city: 'Hassan Abdal', status: 'ACTIVE' },
  { external_id: 'EXT-7783', full_name: 'Hamid Nawaz', phone: '03335550199', city: 'Attock', status: 'PAUSED' },
];
function ApiSync({ db, set, log }: Props) {
  const [lines, setLines] = useState<{ t: string; c: string }[]>([]); const [busy, setBusy] = useState(false); const [json, setJson] = useState('');
  const [session, setSession] = useState<{ app: number; sid: string } | null>(null);
  const run = async () => {
    setBusy(true); setLines([]); setJson('');
    const push = (t: string, c = '#fff') => setLines((l) => [...l, { t, c }]);
    const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
    push('POST /oauth/token   grant_type=client_credentials', '#34eadd'); await wait(500);
    push('← 200 OK  { "access_token": "eyJhbGciOi…", "expires_in": 3600 }', '#36d07e'); await wait(450);
    push('GET  /api/v1/customers?updated_since=last_sync   Authorization: Bearer …', '#34eadd'); await wait(650);
    const batch = EXTERNAL.slice(0, 1 + (db.synced % 3)).map((x) => ({ ...x }));
    setJson(JSON.stringify({ items: batch, count: batch.length, hasMore: false }, null, 2));
    push(`← 200 OK  ${batch.length} record(s) as JSON`, '#36d07e'); await wait(450);
    push('PL/SQL: apex_json.parse → MERGE INTO customers …', '#ffd527'); await wait(500);
    const phoneOf = (x: (typeof EXTERNAL)[number]) => `${x.phone.slice(0, 4)}-${x.phone.slice(4)}`;
    const upd = batch.filter((x) => db.customers.some((c) => c.phone === phoneOf(x))).length, ins = batch.length - upd;
    set((d) => {
      const cs = [...d.customers];
      batch.forEach((x) => {
        const phone = phoneOf(x);
        const st: CStatus = x.status === 'PAUSED' ? 'Paused' : 'Active';
        const i = cs.findIndex((c) => c.phone === phone);
        if (i >= 0) cs[i] = { ...cs[i], name: x.full_name, city: x.city, status: st };
        else cs.unshift({ id: `C-${1001 + cs.length}`, name: x.full_name, phone, city: x.city, status: st, created: ymd(new Date()), source: 'API' });
      });
      return { ...d, customers: cs, synced: d.synced + 1 };
    });
    push(`✔ Sync complete — inserted ${ins}, updated ${upd}. Logged to SYNC_LOG.`, '#36d07e');
    log(`REST sync: ${batch.length} customer(s) merged`); setBusy(false);
  };
  return (
    <div className="grid lg:grid-cols-2 gap-5">
      <div>
        <H sub="Authenticate, fetch JSON, merge into Oracle tables — then see new rows in Customers.">REST API sync</H>
        <div className="rounded-2xl border-2 border-black bg-black text-white p-4 font-mono text-xs min-h-[220px]">
          <div className="text-white/50 mb-2">sync_customers.run</div>
          {lines.map((l, i) => <motion.div key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} style={{ color: l.c }} className="break-all">{l.t}</motion.div>)}
          {!lines.length && <div className="text-white/50">Press “Run sync” to call the external API.</div>}
        </div>
        <div className="mt-3"><Key color="teal" onClick={() => !busy && run()}><RefreshCw className={`w-4 h-4 ${busy ? 'animate-spin' : ''}`} /> {busy ? 'Syncing…' : 'Run sync'}</Key></div>
        {json && <pre className="mt-4 rounded-2xl border-2 border-black bg-white text-black p-4 text-xs overflow-auto max-h-64">{json}</pre>}
      </div>
      <div>
        <H sub="Sign in once in App 1, continue in App 2 — identity passed through application items + a session cookie.">Auto-login between apps</H>
        <Card className="p-4">
          <div className="grid grid-cols-2 gap-3">
            {[1, 2].map((app) => (
              <div key={app} className={`rounded-xl border-2 border-black p-3 ${session?.app === app ? 'bg-[#a8f5ee]' : 'bg-[#f3f3f3]'}`}>
                <div className="display text-lg">App {app}</div>
                <div className="font-serif text-xs">{app === 1 ? 'Customer portal' : 'CareBox ordering'}</div>
                <div className="mt-2 text-xs font-bold">{session ? <span className="inline-flex items-center gap-1"><Check className="w-3 h-3" />Signed in</span> : <span className="inline-flex items-center gap-1"><Lock className="w-3 h-3" />Signed out</span>}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {!session && <Key sm color="yellow" onClick={() => { const sid = Math.random().toString(36).slice(2, 10).toUpperCase(); setSession({ app: 1, sid }); log('Customer signed in to App 1'); }}><KeyRound className="w-4 h-4" /> Sign in to App 1</Key>}
            {session?.app === 1 && <Key sm color="teal" onClick={() => { setSession({ ...session, app: 2 }); log('Auto-login to App 2 (no password)'); }}><Send className="w-4 h-4" /> Open App 2</Key>}
            {session && <Key sm color="white" onClick={() => setSession(null)}>Sign out</Key>}
          </div>
          <div className="mt-4 rounded-xl border-2 border-black bg-black text-[#34eadd] font-mono text-[11px] p-3 leading-relaxed">
            <div>G_CUSTOMER_ID  = {session ? 'C-1001' : 'null'}</div>
            <div>G_AUTH_SOURCE  = {session ? (session.app === 2 ? 'AUTO_LOGIN' : 'PASSWORD') : 'null'}</div>
            <div>cookie CBX_SSO = {session ? session.sid : '—'}</div>
            <div>APP_SESSION    = {session ? `${session.app}0${session.sid.slice(0, 6)}` : '—'}</div>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ---------------- shell ---------------- */
type Props = { db: DB; set: (f: (d: DB) => DB) => void; log: (t: string) => void };
const TABS = [
  { k: 'dash', l: 'Dashboard', I: LayoutDashboard, c: 'teal' },
  { k: 'cust', l: 'Customers', I: Users, c: 'white' },
  { k: 'new', l: 'New CareBox', I: PackagePlus, c: 'yellow' },
  { k: 'appr', l: 'Approve & Sign', I: PenLine, c: 'pink' },
  { k: 'api', l: 'REST API & Login', I: RefreshCw, c: 'dark' },
] as const;

export default function CareBoxLab() {
  const [db, setDb] = useState<DB>(load);
  const [tab, setTab] = useState<(typeof TABS)[number]['k']>('dash');
  const [cust, setCust] = useState('');
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch { /* ignore */ } }, [db]);
  useEffect(() => { window.scrollTo(0, 0); }, []);
  const log = (text: string) => setDb((d) => ({ ...d, log: [{ ts: now(), text }, ...d.log].slice(0, 40) }));
  const props: Props = { db, set: setDb, log };
  const open = useMemo(() => db.orders.filter((o) => o.stage !== 'Applied').length, [db.orders]);
  return (
    <main className="min-h-screen bg-[#f3f3f3] dark:bg-coal text-black">
      <header className="relative bg-black text-white pt-24 pb-10 overflow-hidden">
        <div className="absolute right-[-30px] top-12 w-[280px] opacity-30 hidden sm:block" aria-hidden>
          <svg viewBox="0 0 200 160"><path d="M20 60 L100 20 L180 60 L100 100 Z" fill="#34eadd" stroke="#fff" strokeWidth="5" strokeLinejoin="round" /><path d="M20 60 V120 L100 150 V100 M180 60 V120 L100 150" fill="none" stroke="#fff" strokeWidth="5" strokeLinejoin="round" /><path d="M85 55 h30 M100 40 v30" stroke="#ff4f81" strokeWidth="9" strokeLinecap="round" /></svg>
        </div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-8">
          <a href="#work" className="inline-flex items-center gap-2 font-serif text-white/80 hover:text-yellow mb-5"><ArrowLeft className="w-4 h-4" /> Back to portfolio</a>
          <div className="serif-i text-lg text-yellow">Oracle APEX project · live demo</div>
          <h1 className="display text-[clamp(44px,8vw,104px)]">Public CareBox</h1>
          <p className="font-serif text-white/80 max-w-2xl mt-3">Customers, CareBox ordering, approval + signature + Apply, status workflows, admin dashboard, REST API sync and auto-login — the flows Ahmed builds in Oracle APEX, recreated here so you can click through them. Data stays in your browser.</p>
        </div>
      </header>
      <div className="sticky top-0 z-30 bg-[#f3f3f3]/95 dark:bg-coal/95 backdrop-blur border-b-2 border-black">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 py-3 flex gap-2 overflow-x-auto no-scrollbar items-center pr-[190px]">
          {TABS.map(({ k, l, I, c }) => (
            <Key key={k} sm serif color={c as any} active={tab === k} onClick={() => setTab(k)}>
              <I className="w-4 h-4" /><span className="text-[15px] whitespace-nowrap">{l}</span>
              {k === 'appr' && open > 0 && <span className="ml-1 text-[10px] bg-black text-white rounded-full px-1.5">{open}</span>}
            </Key>
          ))}
          <Key sm color="white" onClick={() => setDb(seed())} title="Reset demo data"><RotateCcw className="w-4 h-4" /></Key>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-4 sm:px-8 py-8">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.25 }}>
            {tab === 'dash' && <Dashboard db={db} />}
            {tab === 'cust' && <Customers {...props} go={(id) => { setCust(id); setTab('new'); }} />}
            {tab === 'new' && <NewOrder {...props} cust={cust} setCust={setCust} done={() => setTab('appr')} />}
            {tab === 'appr' && <Approvals {...props} />}
            {tab === 'api' && <ApiSync {...props} />}
          </motion.div>
        </AnimatePresence>
        <div className="mt-10 grid sm:grid-cols-3 gap-4">
          {[['Status workflows', 'Active, inactive, paused, deleted — the status decides what the UI allows.'], ['Validations', 'Phone format, duplicates, product maximums, empty boxes.'], ['Integration', 'Token → JSON → PL/SQL MERGE, plus auto-login across apps.']].map(([t, d]) => (
            <div key={t} className="rounded-2xl border-2 border-black bg-white p-4"><div className="display text-xl">{t}</div><div className="font-serif text-sm mt-1">{d}</div></div>
          ))}
        </div>
        <div className="mt-6 flex items-center gap-2 text-xs font-serif italic dark:text-white/70"><AlertTriangle className="w-3 h-3" /> Demo with sample data. The real Public CareBox is client work built in Oracle APEX + SQL / PL/SQL at S&H Software Solution.</div>
      </div>
    </main>
  );
}

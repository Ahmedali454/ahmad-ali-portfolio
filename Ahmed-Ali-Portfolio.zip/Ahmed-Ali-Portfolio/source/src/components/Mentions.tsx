import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X } from 'lucide-react';
import { Arrow, Key } from './kit';
import { BLOG, EXPERIENCE } from '../data';
import { Markdown } from '../lib/md';

const PILL = ['#34eadd', '#ffd527', '#ff4f81', '#a8f5ee'];

function MiniCard({ pill, pc, title, sub, onClick, open, children, i }: {
  pill: string; pc: string; title: string; sub: string; onClick: () => void; open?: boolean; children?: React.ReactNode; i: number;
}) {
  return (
    <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (i % 3) * 0.08 }}
      whileHover={{ y: -6, rotate: i % 2 ? 0.8 : -0.8 }}
      className="rounded-[16px] border border-black/15 dark:border-white/15 bg-paper p-6 flex flex-col items-center text-center shadow-[0_1px_0_rgba(0,0,0,.04)]">
      <span className="text-[12px] font-bold font-serif px-3 py-1 rounded-full border-2 border-black text-black" style={{ background: pc }}>{pill}</span>
      <h3 className="font-serif font-bold text-[22px] leading-tight mt-4">{title}</h3>
      <div className="serif-i text-muted text-sm mt-2">{sub}</div>
      <AnimatePresence initial={false}>
        {open && children && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden w-full">
            <div className="pt-4 text-left">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="mt-auto pt-6"><Key color="dark" icon onClick={onClick} title={open ? 'Close' : 'Open'}><Arrow className={`w-5 h-5 transition-transform ${open ? 'rotate-[135deg]' : ''}`} /></Key></div>
    </motion.div>
  );
}

export function Mentions() {
  const [exp, setExp] = useState<number | null>(0);
  const [post, setPost] = useState<number | null>(null);
  return (
    <section className="bg-paper text-ink py-20 sm:py-28 border-t-2 border-black/5">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <h2 className="display text-center text-[clamp(52px,8.5vw,112px)]">Experience</h2>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-5 items-start">
          {EXPERIENCE.map((x, i) => (
            <MiniCard key={x.role} i={i} pill={x.when} pc={PILL[i % 4]} title={x.role} sub={x.org} open={exp === i} onClick={() => setExp(exp === i ? null : i)}>
              <ul className="space-y-1.5">{x.points.map((p) => <li key={p} className="flex gap-2 font-serif text-[15px]"><span className="mt-2 w-1.5 h-1.5 rotate-45 bg-ink shrink-0" />{p}</li>)}</ul>
              <div className="mt-3 flex flex-wrap gap-1.5">{x.tags.map((t) => <span key={t} className="text-[11px] font-bold border border-ink/40 rounded-full px-2 py-0.5">{t}</span>)}</div>
            </MiniCard>
          ))}
        </div>

        <h2 id="writing" className="display text-center text-[clamp(52px,8.5vw,112px)] mt-24 scroll-mt-20">Writing</h2>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {BLOG.map((b, i) => (
            <MiniCard key={b.id} i={i} pill={`${b.tag} · ${b.read}`} pc={PILL[(i + 1) % 4]} title={b.title} sub={b.excerpt} onClick={() => setPost(i)} />
          ))}
        </div>
      </div>

      <AnimatePresence>
        {post !== null && (
          <motion.div className="fixed inset-0 z-[80] bg-black/70 overflow-y-auto p-3 sm:p-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setPost(null)}>
            <motion.article initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 30, opacity: 0 }} onClick={(e) => e.stopPropagation()}
              className="relative mx-auto max-w-2xl bg-white text-black rounded-[22px] border-2 border-black p-6 sm:p-10">
              <div className="absolute top-4 right-4"><Key icon sm onClick={() => setPost(null)} title="Close"><X className="w-4 h-4" /></Key></div>
              <span className="text-[12px] font-bold font-serif px-3 py-1 rounded-full border-2 border-black bg-teal">{BLOG[post].tag} · {BLOG[post].date} · {BLOG[post].read}</span>
              <h3 className="display text-4xl sm:text-5xl mt-4">{BLOG[post].title}</h3>
              <Markdown text={BLOG[post].body} className="prose-mu mt-4" />
            </motion.article>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { Burst, Key } from './kit';
import { EDUCATION } from '../data';

const TONES = [
  { glow: '#34eadd', burst: '#34eadd' },
  { glow: '#ff4f81', burst: '#ffd527' },
  { glow: '#ffd527', burst: '#ff4f81' },
];

export function Education() {
  const [i, setI] = useState(0);
  const [dir, setDir] = useState(1);
  const go = (d: number) => { setDir(d); setI((v) => (v + d + EDUCATION.length) % EDUCATION.length); };
  const e = EDUCATION[i]; const t = TONES[i % TONES.length];
  const bottom = [
    [e.year, 'Year'],
    [e.grade || e.school.split(',')[0], e.grade ? 'Grade' : 'School'],
    [e.place, 'Location'],
  ];
  return (
    <section id="education" className="bg-yellow text-black py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <h2 className="display text-center text-[clamp(56px,9vw,120px)]">Education</h2>
        <div className="relative mt-10">
          <div className="relative rounded-[22px] border-2 border-black bg-black text-white overflow-hidden min-h-[460px] sm:min-h-[520px] select-none">
            <AnimatePresence mode="popLayout" custom={dir} initial={false}>
              <motion.div key={i} custom={dir}
                initial={{ x: dir * 120, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -dir * 120, opacity: 0 }}
                transition={{ type: 'spring', stiffness: 220, damping: 26 }}
                drag="x" dragConstraints={{ left: 0, right: 0 }} dragElastic={0.25}
                onDragEnd={(_, info) => { if (info.offset.x < -80) go(1); else if (info.offset.x > 80) go(-1); }}
                className="absolute inset-0 flex flex-col cursor-grab active:cursor-grabbing">
                <div className="absolute inset-0" style={{ background: `radial-gradient(60% 70% at 70% 30%, ${t.glow}55, transparent 70%), radial-gradient(50% 60% at 15% 90%, #ffffff18, transparent 70%)` }} />
                <Burst color={t.burst} points={18} className="absolute -right-16 -top-16 w-72 h-72 opacity-90" />
                <div className="absolute right-6 sm:right-14 top-10 sm:top-14 display text-[120px] sm:text-[200px] text-white/[0.06] leading-none">{e.year.slice(-4)}</div>
                <div className="relative flex-1 flex flex-col items-center justify-center text-center px-6 pt-10">
                  <div className="serif-i text-white/80 text-lg">{e.school}</div>
                  <div className="display text-[clamp(40px,7vw,88px)] mt-2">{e.degree}</div>
                  <div className="mt-5 flex flex-wrap justify-center gap-2 max-w-2xl">
                    {e.courses.length > 0 && e.courses.map((c) => <span key={c} className="rounded-full border-2 border-white/80 px-3 py-1 text-sm font-serif">{c}</span>)}
                  </div>
                </div>
                <div className="relative grid grid-cols-3 gap-2 px-5 sm:px-10 pb-6 pt-6 border-t border-white/15 bg-black/40 backdrop-blur-sm">
                  {bottom.map(([a, b], k) => (
                    <div key={k} className={k === 0 ? 'text-left' : k === 1 ? 'text-center' : 'text-right'}>
                      <div className="serif-i font-bold text-sm sm:text-base">{a}</div>
                      <div className="font-serif text-white/70 text-xs sm:text-sm">{b}</div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="hidden sm:block absolute -left-5 top-1/2 -translate-y-1/2 z-10"><Key icon onClick={() => go(-1)} title="Previous"><ArrowLeft className="w-5 h-5" /></Key></div>
          <div className="hidden sm:block absolute -right-5 top-1/2 -translate-y-1/2 z-10"><Key icon onClick={() => go(1)} title="Next"><ArrowRight className="w-5 h-5" /></Key></div>
        </div>
        <div className="mt-6 flex justify-center items-center gap-2">
          <span className="sm:hidden mr-2"><Key icon sm onClick={() => go(-1)} title="Previous"><ArrowLeft className="w-4 h-4" /></Key></span>
          {EDUCATION.map((_, k) => (
            <button key={k} onClick={() => { setDir(k > i ? 1 : -1); setI(k); }} aria-label={`Slide ${k + 1}`}
              className={`h-3 rounded-full border-2 border-black transition-all ${k === i ? 'w-10 bg-black' : 'w-3 bg-white'}`} />
          ))}
          <span className="sm:hidden ml-2"><Key icon sm onClick={() => go(1)} title="Next"><ArrowRight className="w-4 h-4" /></Key></span>
        </div>
      </div>
    </section>
  );
}

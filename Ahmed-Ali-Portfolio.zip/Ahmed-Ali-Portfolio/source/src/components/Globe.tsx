import { useEffect, useRef, useState } from 'react';
import createGlobe from 'cobe';
import { Crosshair } from 'lucide-react';
import { PROFILE } from '../data';

const toPhi = (lng: number) => Math.PI - ((lng * Math.PI) / 180 - Math.PI / 2);

export default function Globe() {
  const dark = true;
  const canvas = useRef<HTMLCanvasElement>(null);
  const pointer = useRef<number | null>(null);
  const drag = useRef(0);
  const focus = useRef<number | null>(toPhi(PROFILE.coords.lng));
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const c = canvas.current!;
    let phi = 0, width = c.offsetWidth;
    const onResize = () => (width = c.offsetWidth);
    addEventListener('resize', onResize);
    const g = createGlobe(c, {
      devicePixelRatio: 2, width: width * 2, height: width * 2, phi: 0, theta: 0.42,
      dark: dark ? 1 : 0, diffuse: dark ? 1.4 : 1.6, mapSamples: 18000, mapBrightness: 9, mapBaseBrightness: dark ? 0 : 0.05,
      baseColor: [0.32, 0.32, 0.32],
      markerColor: [1, 0.84, 0.15], glowColor: [0.2, 0.92, 0.87],
      markers: [
        { location: [PROFILE.coords.lat, PROFILE.coords.lng], size: 0.11 },
      ],
      onRender: (state) => {
        if (focus.current !== null && pointer.current === null) {
          const target = focus.current; const d = ((target - phi + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
          phi += d * 0.06; if (Math.abs(d) < 0.003) focus.current = null;
        } else if (pointer.current === null) phi += 0.0035;
        state.phi = phi + drag.current; state.theta = 0.42;
        state.width = width * 2; state.height = width * 2;
      },
    });
    setTimeout(() => setReady(true), 50);
    return () => { g.destroy(); removeEventListener('resize', onResize); };
  }, [dark]);

  return (
    <div className="relative aspect-square w-full max-w-[300px] mx-auto">
      <canvas ref={canvas}
        className={`w-full h-full cursor-grab active:cursor-grabbing transition-opacity duration-1000 ${ready ? 'opacity-100' : 'opacity-0'}`}
        style={{ contain: 'layout paint size' }}
        onPointerDown={(e) => { pointer.current = e.clientX - drag.current * 200; focus.current = null; }}
        onPointerUp={() => (pointer.current = null)} onPointerOut={() => (pointer.current = null)}
        onPointerMove={(e) => { if (pointer.current !== null) drag.current = (e.clientX - pointer.current) / 200; }}
        onTouchMove={(e) => { if (pointer.current !== null && e.touches[0]) drag.current = (e.touches[0].clientX - pointer.current) / 100; }}
      />
      <button onClick={() => { drag.current = 0; focus.current = toPhi(PROFILE.coords.lng); }}
        className="absolute bottom-1 right-1 bg-yellow text-black border-2 border-black rounded-xl px-3 py-1.5 text-xs font-bold inline-flex items-center gap-1.5 hover:-translate-y-0.5 transition">
        <Crosshair className="w-3.5 h-3.5" /> Locate Hassan Abdal
      </button>
    </div>
  );
}

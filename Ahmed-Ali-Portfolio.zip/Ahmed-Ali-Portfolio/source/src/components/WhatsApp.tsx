import { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, CheckCheck } from 'lucide-react';
import { PROFILE, waLink } from '../data';
import { BrandIcon } from '../lib/ui';

const QUICK = [
  { l: '💼 Job opportunity', t: "Hi Ahmed! I have a job opportunity for you. Are you available to discuss?" },
  { l: '🚀 Freelance project', t: 'Hi Ahmed! I want to hire you for a freelance project. Can you share your availability and rates?' },
  { l: '🗄️ Oracle APEX app', t: 'Hi Ahmed! I need an Oracle APEX application built. Can we discuss requirements?' },
  { l: '🔌 REST API integration', t: 'Hi Ahmed! I need REST API integration / data sync for my application. Can we talk?' },
  { l: '🧮 SQL / PL/SQL', t: 'Hi Ahmed! I need help with SQL / PL/SQL development. Are you available?' },
];

function greeting() {
  const h = Number(new Date().toLocaleString('en-US', { timeZone: PROFILE.timezone, hour: 'numeric', hour12: false }));
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}

export default function WhatsApp() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');
  const sendRef = useRef<HTMLAnchorElement>(null);
  const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  return (
    <>
      <motion.button onClick={() => setOpen(!open)} whileHover={{ rotate: 4 }} aria-label="WhatsApp"
        className="key k-green fixed bottom-[5.6rem] right-4 sm:right-6 z-[60]">
        <span className="face !p-2.5">{open ? <X className="w-5 h-5" /> : <BrandIcon name="whatsapp" size={22} />}</span>
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: 30, scale: 0.94 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 30, scale: 0.94 }}
            style={{ transformOrigin: 'bottom right' }} transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            className="fixed z-[65] bottom-[10rem] left-2 right-2 sm:left-auto sm:right-6 sm:w-[360px] rounded-[22px] overflow-hidden shadow-[8px_10px_0_#000] border-2 border-black">
            <div className="bg-[#075E54] text-white px-4 py-3 flex items-center gap-3">
              <div className="relative"><img src={PROFILE.avatarSm} alt="" className="w-10 h-10 rounded-full object-cover object-top" /><span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#25D366] ring-2 ring-[#075E54]" /></div>
              <div className="flex-1"><div className="font-semibold text-sm">Ahmed Ali</div><div className="text-[11px] opacity-80">Typically replies within an hour</div></div>
              <button onClick={() => setOpen(false)} aria-label="Close" className="opacity-80 hover:opacity-100"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-4 space-y-3 max-h-[52vh] overflow-y-auto" style={{ background: '#ECE5DD', backgroundImage: 'radial-gradient(rgba(0,0,0,.05) 1px, transparent 1px)', backgroundSize: '14px 14px' }}>
              <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="bg-white text-slate-800 rounded-2xl rounded-tl-sm px-3.5 py-2.5 text-sm shadow-sm max-w-[88%]">
                {greeting()}! 👋 This is Ahmed.<br />How can I help you? Pick a topic or type below.
                <div className="text-[10px] text-slate-400 text-right mt-1">{time}</div>
              </motion.div>
              <div className="flex flex-wrap gap-1.5">
                {QUICK.map((q, i) => (
                  <motion.a key={q.l} href={waLink(q.t)} target="_blank" rel="noopener noreferrer" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 + i * 0.05 }}
                    className="text-xs font-medium bg-white text-[#075E54] border border-[#25D366]/40 rounded-full px-3 py-1.5 hover:bg-[#DCF8C6] transition">{q.l}</motion.a>
                ))}
              </div>
              {text && (
                <div className="flex justify-end"><div className="bg-[#DCF8C6] text-slate-800 rounded-2xl rounded-tr-sm px-3.5 py-2 text-sm max-w-[85%] whitespace-pre-wrap">{text}<div className="text-[10px] text-slate-500 text-right mt-0.5 inline-flex items-center gap-0.5 w-full justify-end">{time} <CheckCheck className="w-3 h-3 text-sky-500" /></div></div></div>
              )}
            </div>
            <form onSubmit={(e) => { e.preventDefault(); if (text.trim()) sendRef.current?.click(); }} className="bg-[#F0F0F0] p-2.5 flex items-center gap-2">
              <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message" className="flex-1 rounded-full bg-white px-4 py-2.5 text-sm text-slate-800 outline-none" />
              <a ref={sendRef} href={text.trim() ? waLink(text) : undefined} target="_blank" rel="noopener noreferrer" aria-label="Send on WhatsApp"
                className={`w-10 h-10 rounded-full grid place-items-center text-white transition ${text.trim() ? 'bg-[#25D366]' : 'bg-slate-400 pointer-events-none'}`}><Send className="w-4 h-4" /></a>
            </form>
            <div className="bg-[#F0F0F0] text-center text-[10px] text-slate-500 pb-2">{PROFILE.phoneIntl} · opens WhatsApp</div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

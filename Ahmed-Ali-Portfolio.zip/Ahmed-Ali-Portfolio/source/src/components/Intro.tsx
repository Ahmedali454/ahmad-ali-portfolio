import { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { FolderOpen, Wrench } from 'lucide-react';
import { Key } from './kit';

export function Streaks({ density = 70 }: { density?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!; const x = c.getContext('2d')!; let raf = 0; let w = 0, h = 0;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const resize = () => { w = c.offsetWidth; h = c.offsetHeight; c.width = w * dpr; c.height = h * dpr; x.setTransform(dpr, 0, 0, dpr, 0, 0); };
    resize(); const ro = new ResizeObserver(resize); ro.observe(c);
    const P = Array.from({ length: density }, () => ({ x: Math.random(), y: Math.random(), l: 4 + Math.random() * 7, s: 0.00015 + Math.random() * 0.0004, o: 0.35 + Math.random() * 0.6 }));
    const tick = () => {
      x.clearRect(0, 0, w, h); x.lineCap = 'round'; x.lineWidth = 1.6;
      for (const p of P) {
        p.x += p.s; p.y -= p.s; if (p.x > 1.02) p.x = -0.02; if (p.y < -0.02) p.y = 1.02;
        x.strokeStyle = `rgba(255,255,255,${p.o})`; x.beginPath(); x.moveTo(p.x * w, p.y * h); x.lineTo(p.x * w + p.l, p.y * h - p.l); x.stroke();
      }
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [density]);
  return <canvas ref={ref} className="absolute inset-0 w-full h-full pointer-events-none" aria-hidden />;
}

const LINE_1 = ['ORACLE APEX', 'DEVELOPER'];
const LINE_2 = 'WHO TURNS BUSINESS REQUIREMENTS INTO APEX APPS WITH PL/SQL, DASHBOARDS AND REST APIs.'.split(' ');

/** Original illustration: a laptop surfing teal waves. */
function WaveBand() {
  const wave = (d: string, fill: string) => <path d={d} fill={fill} stroke="#000" strokeWidth="3" strokeLinejoin="round" />;
  const crest = (yy: number) => {
    let d = `M0 ${yy}`;
    for (let i = 0; i < 16; i++) { const x0 = i * 100; d += ` C${x0 + 25} ${yy - 46} ${x0 + 70} ${yy - 46} ${x0 + 78} ${yy - 14} C${x0 + 80} ${yy - 30} ${x0 + 62} ${yy - 30} ${x0 + 66} ${yy - 12} C${x0 + 80} ${yy + 6} ${x0 + 92} ${yy + 4} ${x0 + 100} ${yy}`; }
    return d + ` L1600 400 L0 400 Z`;
  };
  return (
    <div className="relative h-[300px] sm:h-[400px] overflow-hidden bg-black border-b-2 border-black" aria-hidden>
      {/* surfer laptop */}
      <div className="absolute left-1/2 top-[6%] -translate-x-1/2 w-[210px] sm:w-[300px] bob z-10">
        <svg viewBox="0 0 300 220">
          <ellipse cx="150" cy="196" rx="138" ry="16" fill="#ffd527" stroke="#000" strokeWidth="4" />
          <path d="M40 196 h220" stroke="#000" strokeWidth="2" opacity=".35" />
          <rect x="70" y="40" width="160" height="104" rx="10" fill="#fff" stroke="#000" strokeWidth="5" />
          <rect x="82" y="52" width="136" height="80" rx="4" fill="#131212" />
          <text x="92" y="76" fontFamily="monospace" fontSize="13" fill="#34eadd">&lt;Ahmed /&gt;</text>
          <text x="92" y="96" fontFamily="monospace" fontSize="11" fill="#ffd527">build();</text>
          <text x="92" y="114" fontFamily="monospace" fontSize="11" fill="#ff4f81">test(); ship();</text>
          <path d="M52 144 h196 l20 28 h-236 z" fill="#ececec" stroke="#000" strokeWidth="5" strokeLinejoin="round" />
          <rect x="132" y="152" width="36" height="8" rx="3" fill="#000" opacity=".25" />
          <path d="M110 172 l-10 22 M190 172 l10 22" stroke="#000" strokeWidth="5" strokeLinecap="round" />
        </svg>
      </div>
      {[
        { y: 230, fill: '#1c8f86', dur: 26, top: '22%' },
        { y: 250, fill: '#34eadd', dur: 18, top: '42%' },
        { y: 260, fill: '#279a92', dur: 12, top: '62%' },
      ].map((w, i) => (
        <div key={i} className="absolute left-0 w-[200%] h-full" style={{ top: w.top, animation: `wave1 ${w.dur}s linear infinite ${i % 2 ? 'reverse' : ''}`, zIndex: i === 0 ? 0 : 20 }}>
          <svg viewBox="0 0 1600 400" preserveAspectRatio="none" className="w-1/2 h-full float-left">{wave(crest(w.y - 160), w.fill)}</svg>
          <svg viewBox="0 0 1600 400" preserveAspectRatio="none" className="w-1/2 h-full float-left">{wave(crest(w.y - 160), w.fill)}</svg>
        </div>
      ))}
    </div>
  );
}

export function Intro() {
  const word = (w: string, i: number, cls = '') => (
    <motion.span key={w + i} className={`inline-block mr-[0.25em] ${cls}`} initial={{ opacity: 0, y: '0.6em' }} whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }} transition={{ delay: i * 0.05, duration: 0.5 }}>{w}</motion.span>
  );
  return (
    <section id="about" className="bg-black text-white">
      <div className="relative py-24 sm:py-36 overflow-hidden">
        <Streaks />
        <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
          <div className="serif-i font-bold text-2xl sm:text-3xl mb-3">I'm a</div>
          <h2 className="display text-[clamp(40px,6.4vw,84px)] max-w-5xl">
            {LINE_1.map((w, i) => word(w, i, 'text-yellow'))}
            {LINE_2.map((w, i) => word(w, i + 2))}
          </h2>
          <div className="mt-10 flex flex-wrap gap-3">
            <Key color="teal" icon href="#work" title="Work"><FolderOpen className="w-6 h-6" /></Key>
            <Key color="white" icon href="#services" title="Services"><Wrench className="w-6 h-6" /></Key>
          </div>
        </div>
      </div>
      <WaveBand />
    </section>
  );
}

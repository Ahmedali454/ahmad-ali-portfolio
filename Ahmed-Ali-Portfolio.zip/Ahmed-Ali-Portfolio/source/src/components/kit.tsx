import { ReactNode, useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';

export type KeyColor = 'teal' | 'yellow' | 'pink' | 'dark' | 'white' | 'black' | 'green';

type KeyProps = {
  children: ReactNode; color?: KeyColor; href?: string; onClick?: () => void; sm?: boolean; icon?: boolean;
  serif?: boolean; className?: string; title?: string; newTab?: boolean; active?: boolean; type?: 'button' | 'submit';
};

/** Chunky 3D keycap button (pressable). */
export function Key({ children, color = 'white', href, onClick, sm, icon, serif, className = '', title, newTab, active, type = 'button' }: KeyProps) {
  const cls = `key k-${color} ${sm ? 'sm' : ''} ${icon ? 'icon' : ''} ${serif ? 'serif' : ''} ${active ? 'active' : ''} ${className}`;
  if (href) {
    const ext = newTab ?? /^https?:/.test(href);
    return (
      <a href={href} className={cls} title={title} aria-label={title} onClick={onClick}
        {...(ext ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>
        <span className="face">{children}</span>
      </a>
    );
  }
  return (
    <button type={type} className={cls} onClick={onClick} title={title} aria-label={title} aria-pressed={active}>
      <span className="face">{children}</span>
    </button>
  );
}

/** Boxed-letter wordmark. */
export function Logo({ invert = false, className = '' }: { invert?: boolean; className?: string }) {
  const c = invert ? '#000' : '#fff';
  const box = (ch: string, i: number) => (
    <span key={i} className="grid place-items-center w-[15px] h-[15px] rounded-[3px] text-[9px] font-bold leading-none"
      style={{ border: `1.6px solid ${c}`, color: c, fontFamily: 'Arial, sans-serif' }}>{ch}</span>
  );
  return (
    <a href="#top" className={`inline-flex flex-col gap-[3px] ${className}`} aria-label="Ahmed Ali — home">
      <span className="flex gap-[3px]">{'AHMED'.split('').map(box)}</span>
      <span className="flex gap-[3px]">{'ALI'.split('').map(box)}</span>
      <span className="text-[7.5px] tracking-[0.32em] font-bold mt-[1px]" style={{ color: c, fontFamily: 'Arial, sans-serif' }}>APEX&nbsp;DEV.</span>
    </a>
  );
}

/** Letter-roll hover text. */
export function Roll({ text, className = '' }: { text: string; className?: string }) {
  return (
    <span className={`roll ${className}`} aria-label={text}>
      {text.split('').map((c, i) => (
        <span key={i} data-c={c} style={{ ['--i' as any]: i }} aria-hidden>{c === ' ' ? ' ' : c}</span>
      ))}
    </span>
  );
}

export function Reveal({ children, delay = 0, y = 40, className = '' }: { children: ReactNode; delay?: number; y?: number; className?: string }) {
  return (
    <motion.div className={className} initial={{ opacity: 0, y }} whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7, delay, ease: [0.2, 0.7, 0.2, 1] }}>
      {children}
    </motion.div>
  );
}

export function useInView<T extends Element>(margin = '0px') {
  const ref = useRef<T>(null);
  const [v, setV] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setV(true), { rootMargin: margin });
    io.observe(el); return () => io.disconnect();
  }, [margin]);
  return [ref, v] as const;
}

/** Spiky starburst behind illustrations. */
export function Burst({ color = '#34eadd', points = 14, className = '' }: { color?: string; points?: number; className?: string }) {
  const pts: string[] = [];
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 ? 30 : 50; const a = (Math.PI * i) / points;
    pts.push(`${50 + r * Math.cos(a)},${50 + r * Math.sin(a)}`);
  }
  return <svg viewBox="0 0 100 100" className={className}><polygon points={pts.join(' ')} fill={color} stroke="#000" strokeWidth="1.6" strokeLinejoin="round" /></svg>;
}

export const Arrow = ({ className = 'w-4 h-4' }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M7 17 17 7M8 7h9v9" /></svg>
);

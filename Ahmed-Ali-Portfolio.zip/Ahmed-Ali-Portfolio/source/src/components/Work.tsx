import { useState } from 'react';
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { Eye, X, Github, ExternalLink, Sparkles, Globe, Database, Brain, ShieldCheck, LayoutGrid } from 'lucide-react';
import { Arrow, Key } from './kit';
import { PROJECTS, PROFILE, type Project } from '../data';
import { openChat } from './Menu';

const TABS = [
  { k: 'All', label: 'All Work', color: 'pink', I: LayoutGrid },
  { k: 'Enterprise', label: 'Oracle APEX', color: 'teal', I: Database },
  { k: 'Integration', label: 'REST & Integration', color: 'yellow', I: Globe },
  { k: 'Marketplace', label: 'Marketplace', color: 'white', I: ShieldCheck },
] as const;

function Card({ p, onOpen, i }: { p: Project; onOpen: () => void; i: number }) {
  const rx = useMotionValue(0), ry = useMotionValue(0);
  const sx = useSpring(rx, { stiffness: 200, damping: 18 }), sy = useSpring(ry, { stiffness: 200, damping: 18 });
  const rotX = useTransform(sy, (v) => v * -8), rotY = useTransform(sx, (v) => v * 10);
  return (
    <motion.article layout initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }}
      exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.55, delay: (i % 2) * 0.08 }} className="group">
      <motion.button onClick={onOpen} className="block w-full text-left [perspective:900px]" aria-label={`Open ${p.title}`}
        onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); rx.set((e.clientX - r.left) / r.width - 0.5); ry.set((e.clientY - r.top) / r.height - 0.5); }}
        onMouseLeave={() => { rx.set(0); ry.set(0); }}>
        <motion.div style={{ rotateX: rotX, rotateY: rotY }} className="relative aspect-[16/10] rounded-[18px] overflow-hidden border-2 border-black bg-black">
          <img src={p.img} alt={`${p.title} screenshot`} loading="lazy" className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-[1.06]" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition" />
          <span className={`absolute top-3 left-3 text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border-2 border-black ${p.status === 'Live' ? 'bg-[#36d07e]' : p.status === 'Demo' ? 'bg-yellow' : 'bg-white'}`}>
            {p.status === 'Live' ? '● Live' : p.status === 'Demo' ? '▶ Live demo' : p.status}
          </span>
        </motion.div>
      </motion.button>
      <div className="mt-3 flex items-start justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-wider font-sans">{p.client}</div>
          <h3 className="display text-[26px] sm:text-[30px] mt-0.5">{p.title}</h3>
        </div>
        <Key color="teal" icon onClick={onOpen} title={`Open ${p.title}`}><Arrow className="w-5 h-5" /></Key>
      </div>
    </motion.article>
  );
}

function Detail({ p, onClose }: { p: Project; onClose: () => void }) {
  const live = p.live; const internal = live?.startsWith('#');
  return (
    <motion.div className="fixed inset-0 z-[80] bg-black/75 overflow-y-auto p-3 sm:p-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }} transition={{ type: 'spring', stiffness: 220, damping: 24 }}
        onClick={(e) => e.stopPropagation()} className="relative mx-auto max-w-4xl bg-white text-black rounded-[24px] border-2 border-black overflow-hidden">
        <div className="absolute top-3 right-3 z-10"><Key icon onClick={onClose} title="Close"><X className="w-5 h-5" /></Key></div>
        <div className="aspect-[16/9] bg-black border-b-2 border-black"><img src={p.img} alt={p.title} className="w-full h-full object-cover object-top" /></div>
        <div className="p-5 sm:p-8">
          <div className="text-xs font-bold uppercase tracking-wider">{p.client}</div>
          <h3 className="display text-4xl sm:text-6xl mt-1">{p.title}</h3>
          <p className="serif-i text-lg mt-2">{p.summary}</p>
          <div className="grid sm:grid-cols-2 gap-4 mt-6">
            <div className="rounded-2xl border-2 border-black p-4 bg-[#ffe6ee]"><div className="display text-lg">Problem</div><p className="font-serif mt-1">{p.problem}</p></div>
            <div className="rounded-2xl border-2 border-black p-4 bg-[#dcfaf7]"><div className="display text-lg">Result</div><p className="font-serif mt-1">{p.result}</p></div>
          </div>
          <ul className="mt-5 grid sm:grid-cols-2 gap-2">
            {p.points.map((x) => <li key={x} className="flex gap-2 font-serif"><span className="mt-2 w-2 h-2 rotate-45 bg-black shrink-0" />{x}</li>)}
          </ul>
          <div className="mt-5 flex flex-wrap gap-2">
            {p.stack.map((s) => <span key={s} className="border-2 border-black rounded-full px-3 py-1 text-sm font-bold bg-yellow/60">{s}</span>)}
          </div>
          <div className="mt-7 flex flex-wrap gap-3">
            {live && <Key color="teal" href={live} newTab={!internal} onClick={internal ? onClose : undefined}><ExternalLink className="w-4 h-4" /> {p.liveLabel || 'Visit live website'}</Key>}
            {p.code && <Key color="dark" href={p.code}><Github className="w-4 h-4" /> Source code</Key>}
            <Key color="yellow" onClick={() => { onClose(); openChat(`Tell me about Ahmed's project "${p.title}".`); }}><Sparkles className="w-4 h-4" /> Ask AI</Key>
          </div>
          {!live && <p className="text-sm mt-4 font-serif italic text-black/60">Client / private work — details on request.</p>}
        </div>
      </motion.div>
    </motion.div>
  );
}

export function Work() {
  const [tab, setTab] = useState<string>('All');
  const [open, setOpen] = useState<Project | null>(null);
  const list = PROJECTS.filter((p) => tab === 'All' || p.cat === tab);
  return (
    <section id="work" className="bg-paper text-ink py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <motion.h2 initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          className="display text-center text-[clamp(64px,10vw,130px)] text-pink">Work</motion.h2>
        <div className="mt-6 flex flex-wrap justify-center gap-2.5">
          {TABS.map(({ k, label, color, I }) => (
            <Key key={k} sm serif color={color as any} active={tab === k} onClick={() => setTab(k)}><span className="text-[15px]">{label}</span><I className="w-4 h-4" /></Key>
          ))}
        </div>
        <motion.div layout className="mt-12 grid md:grid-cols-2 gap-x-7 gap-y-12">
          <AnimatePresence mode="popLayout">
            {list.map((p, i) => <Card key={p.id} p={p} i={i} onOpen={() => setOpen(p)} />)}
          </AnimatePresence>
        </motion.div>
        <div className="mt-14 text-center">
          <Key color="dark" href={PROFILE.github}><span className="text-lg">See more work</span><Eye className="w-5 h-5" /></Key>
        </div>
      </div>
      <AnimatePresence>{open && <Detail p={open} onClose={() => setOpen(null)} />}</AnimatePresence>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { motion, useMotionValue, useScroll, useSpring, useTransform } from 'motion/react';
import { ArrowDown, Github, Linkedin, Mail } from 'lucide-react';
import { Key, Logo, Roll } from './kit';
import { PROFILE, gmailCompose, waLink } from '../data';
import { BrandIcon } from '../lib/ui';

function Sticker() {
  return (
    <motion.div drag dragMomentum={false} whileDrag={{ scale: 1.08, rotate: 8 }} whileHover={{ scale: 1.05 }}
      className="absolute right-[6%] top-[22%] z-20 w-28 h-28 sm:w-36 sm:h-36 cursor-grab active:cursor-grabbing hidden sm:block"
      title="Drag me">
      <div className="absolute inset-0 rounded-full bg-yellow border-2 border-black shadow-[5px_6px_0_#000]" />
      <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full" style={{ animation: 'spin 14s linear infinite' }}>
        <defs><path id="circ" d="M50,50 m-37,0 a37,37 0 1,1 74,0 a37,37 0 1,1 -74,0" /></defs>
        <text fontFamily="Oswald, Arial" fontWeight="700" fontSize="10" letterSpacing="1"><textPath href="#circ" textLength="228" lengthAdjust="spacing">AVAILABLE FOR WORK • HIRE ME • </textPath></text>
      </svg>
      <div className="absolute inset-0 grid place-items-center pointer-events-none">
        <span className="w-3.5 h-3.5 rounded-full bg-[#1fd16b] border-2 border-black" />
      </div>
    </motion.div>
  );
}

export function Hero() {
  const { scrollY } = useScroll();
  const scale = useTransform(scrollY, [0, 900], [1.04, 1.18]);
  const y = useTransform(scrollY, [0, 900], [0, 140]);
  const mx = useMotionValue(0), my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 60, damping: 18 }), sy = useSpring(my, { stiffness: 60, damping: 18 });
  const tx = useTransform(sx, (v) => v * -14), ty = useTransform(sy, (v) => v * -10);
  const nx = useTransform(sx, (v) => v * 16), ny = useTransform(sy, (v) => v * 8);
  const [roleI, setRoleI] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setRoleI((i) => (i + 1) % PROFILE.roles.length), 2200);
    return () => clearInterval(t);
  }, []);

  return (
    <section id="top" className="relative h-[100svh] min-h-[560px] overflow-hidden"
      style={{ background: 'radial-gradient(70% 80% at 50% 40%, #2a2226 0%, #141113 55%, #000 100%)' }}
      onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); mx.set((e.clientX - r.left) / r.width - 0.5); my.set((e.clientY - r.top) / r.height - 0.5); }}>
      {/* ghost type behind the portrait */}
      <motion.div className="absolute inset-0 flex flex-col justify-center gap-2 select-none pointer-events-none" style={{ x: nx }} aria-hidden>
        {['ORACLE APEX', 'PL/SQL · SQL', 'REST · JSON'].map((t, i) => (
          <div key={t} className="display whitespace-nowrap text-[clamp(70px,15vw,250px)] leading-[0.86] text-center"
            style={{ color: 'transparent', WebkitTextStroke: '2px rgba(255,255,255,.12)', transform: `translateX(${(i - 1) * 6}%)` }}>{t}</div>
        ))}
      </motion.div>
      <motion.div className="absolute inset-0" style={{ scale, y }}>
        <motion.img src={PROFILE.avatar} alt={PROFILE.fullName}
          className="absolute bottom-0 left-1/2 -translate-x-1/2 h-[96%] sm:h-[100%] w-auto max-w-none object-contain object-bottom"
          style={{ x: tx, y: ty, WebkitMaskImage: 'linear-gradient(90deg, transparent 0%, #000 18%, #000 82%, transparent 100%), linear-gradient(180deg, transparent 0%, #000 12%)', WebkitMaskComposite: 'source-in', maskImage: 'linear-gradient(90deg, transparent 0%, #000 18%, #000 82%, transparent 100%), linear-gradient(180deg, transparent 0%, #000 12%)', maskComposite: 'intersect' }}
          fetchPriority="high" />
      </motion.div>
      <div className="absolute inset-x-0 bottom-0 h-[55%] bg-gradient-to-t from-black via-black/75 to-transparent pointer-events-none" />

      <div className="absolute top-4 left-4 sm:left-6 z-20 bg-black rounded-xl p-2.5"><Logo /></div>
      <Sticker />

      <motion.div className="absolute inset-x-0 bottom-[12%] sm:bottom-[11%] z-10 text-center text-white px-4" style={{ x: nx, y: ny }}>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="flex items-center justify-center gap-2 serif-i font-bold text-2xl sm:text-4xl mb-1">
          <span className="flex gap-1"><i className="w-2 h-2 rounded-full bg-pink" /><i className="w-2 h-2 rounded-full bg-yellow" /><i className="w-2 h-2 rounded-full bg-teal" /></span>
          I'm
        </motion.div>
        <h1 className="display slant text-[clamp(64px,11.5vw,170px)] leading-[0.9] drop-shadow-[0_4px_30px_rgba(0,0,0,.45)]">
          <motion.span className="block" initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.8, ease: [0.2, 0.8, 0.2, 1] }}>
            <Roll text={`${PROFILE.first} ${PROFILE.last}`} />
          </motion.span>
        </h1>
        <div className="mt-3 sm:mt-4 h-7 overflow-hidden serif-i text-lg sm:text-xl text-white/90">
          <motion.div key={roleI} initial={{ y: 28, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.4 }}>
            {PROFILE.roles[roleI]} · {PROFILE.city}, Pakistan
          </motion.div>
        </div>
      </motion.div>

      <div className="absolute bottom-5 left-4 sm:left-6 z-20 flex gap-2.5">
        <Key icon href={PROFILE.linkedin} title="LinkedIn"><Linkedin className="w-5 h-5" /></Key>
        <Key icon href={PROFILE.github} title="GitHub"><Github className="w-5 h-5" /></Key>
        <Key icon href={gmailCompose()} title="Gmail"><Mail className="w-5 h-5" /></Key>
        <Key icon href={waLink('Hi Ahmed! I visited your portfolio.')} title="WhatsApp"><BrandIcon name="whatsapp" size={20} /></Key>
      </div>
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-20 hidden sm:block">
        <Key icon color="yellow" href="#about" title="Scroll down"><ArrowDown className="w-5 h-5" /></Key>
      </div>
    </section>
  );
}

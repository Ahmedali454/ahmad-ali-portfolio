import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, X, Send, Sparkles, RotateCcw, Cpu } from 'lucide-react';
import { PROFILE } from '../data';
import { getSampler } from '../lib/claude';
import { Markdown } from '../lib/md';
import { buildKnowledge, SYSTEM_PROMPT } from '../ai/knowledge';
import { localAnswer } from '../ai/local';

type Msg = { role: 'user' | 'assistant'; content: string };
const SUGGEST = ['Who is Ahmed?', 'What are his top skills?', 'Show his live projects', 'What is Public CareBox?', 'How can I hire him?', 'Ahmed kahan se hain?'];
const HELLO: Msg = { role: 'assistant', content: `Hi! I'm **Ahmed's AI**. Ask me anything about Ahmed Ali — skills, projects, experience, education or how to hire him. Any language works.` };

export default function ChatBot() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([HELLO]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<'checking' | 'claude' | 'local'>('checking');
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const msgsRef = useRef(msgs); msgsRef.current = msgs;

  useEffect(() => { getSampler().then((s) => setMode(s ? 'claude' : 'local')); }, []);
  useEffect(() => { listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' }); }, [msgs, busy]);
  useEffect(() => {
    const h = (e: Event) => { setOpen(true); const p = (e as CustomEvent).detail; if (typeof p === 'string' && p) setTimeout(() => send(p), 250); else setTimeout(() => inputRef.current?.focus(), 300); };
    addEventListener('open-chat', h); return () => removeEventListener('open-chat', h);
  }, []);

  const push = (m: Msg) => setMsgs((x) => [...x, m]);
  const setLast = (content: string) => setMsgs((x) => { const c = [...x]; c[c.length - 1] = { role: 'assistant', content }; return c; });

  async function typeOut(text: string) {
    push({ role: 'assistant', content: '' });
    for (let i = 0; i <= text.length; i += 4) { setLast(text.slice(0, i)); await new Promise((r) => setTimeout(r, 8)); }
    setLast(text);
  }

  async function send(raw?: string) {
    const q = (raw ?? input).trim();
    if (!q || busy) return;
    setInput(''); push({ role: 'user', content: q }); setBusy(true);
    const history = [...msgsRef.current.filter((m) => m !== HELLO), { role: 'user' as const, content: q }].slice(-12);
    try {
      const sample = await getSampler();
      if (!sample) throw new Error('local');
      const convo = history.map((m, i) => i === 0 && m.role === 'user'
        ? { role: 'user', content: `${SYSTEM_PROMPT}\n\nKNOWLEDGE:\n${buildKnowledge()}\n\n---\nVisitor question: ${m.content}` } : m);
      if (convo[0].role !== 'user') convo.shift();
      // ensure the first message carries the knowledge even after trimming
      if (!String(convo[0].content).includes('KNOWLEDGE:')) convo[0] = { role: 'user', content: `${SYSTEM_PROMPT}\n\nKNOWLEDGE:\n${buildKnowledge()}\n\n---\nVisitor question: ${convo[0].content}` };
      abortRef.current = new AbortController();
      push({ role: 'assistant', content: '' });
      const res = await sample(convo, { cache: false, modelTier: 'default', signal: abortRef.current.signal, onText: ({ text }: { text: string }) => setLast(text) });
      setLast(res.text || localAnswer(q));
      setMode('claude');
    } catch (e: any) {
      setMsgs((x) => (x[x.length - 1]?.role === 'assistant' && !x[x.length - 1].content ? x.slice(0, -1) : x));
      if (e?.code === 'not_granted' || e?.message === 'local') setMode('local');
      await typeOut(localAnswer(q));
    } finally { setBusy(false); }
  }

  return (
    <>
      <motion.button onClick={() => setOpen(!open)} whileHover={{ rotate: -3 }} aria-label="Open AI assistant"
        className="key k-yellow fixed bottom-5 right-4 sm:right-6 z-[60]">
        <span className="face !px-3 sm:!px-4 !py-2.5">
          {open ? <X className="w-5 h-5" /> : <><Sparkles className="w-5 h-5" /><span className="hidden sm:inline text-[17px]">Ask my AI</span></>}
        </span>
        {!open && <span className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 rounded-full bg-pink border-2 border-black animate-pulse" />}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: 30, scale: 0.94 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 30, scale: 0.94 }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }} style={{ transformOrigin: 'bottom right' }}
            className="fixed z-[65] bottom-24 sm:bottom-24 right-2 left-2 sm:left-auto sm:right-6 sm:w-[410px] h-[min(620px,calc(100svh-8rem))] rounded-[22px] bg-white text-black border-2 border-black shadow-[8px_10px_0_#000] flex flex-col overflow-hidden">
            <div className="relative px-4 py-3.5 flex items-center gap-3 border-b-2 border-black bg-black text-white overflow-hidden">
              <div className="relative">
                <img src={PROFILE.avatarSm} alt="" className="w-11 h-11 rounded-xl object-cover object-top border-2 border-yellow" />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-md bg-yellow text-black border border-black grid place-items-center"><Sparkles className="w-3 h-3" /></span>
              </div>
              <div className="relative flex-1 min-w-0">
                <div className="display text-lg leading-none">Ahmed's AI</div>
                <div className="text-[11px] text-white/70 flex items-center gap-1.5 font-serif mt-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${mode === 'claude' ? 'bg-emerald-400' : mode === 'local' ? 'bg-cyan-400' : 'bg-amber-400'}`} />
                  {mode === 'claude' ? 'Claude AI · knows my full portfolio' : mode === 'local' ? 'Smart mode · knows my full portfolio' : 'Connecting…'}
                </div>
              </div>
              <button onClick={() => { abortRef.current?.abort(); setMsgs([HELLO]); }} className="relative w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 grid place-items-center" title="New chat" aria-label="New chat"><RotateCcw className="w-3.5 h-3.5" /></button>
            </div>

            <div ref={listRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
              {msgs.map((m, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={`flex ${m.role === 'user' ? 'justify-end' : 'gap-2'}`}>
                  {m.role === 'assistant' && <div className="w-7 h-7 shrink-0 rounded-lg bg-yellow border-2 border-black grid place-items-center mt-0.5"><Bot className="w-4 h-4" /></div>}
                  <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[13.5px] leading-relaxed ${m.role === 'user' ? 'bg-teal border-2 border-black rounded-br-md' : 'bg-[#f3f3f3] border-2 border-black rounded-tl-md'}`}>
                    {m.content ? <Markdown text={m.content} /> : <span className="inline-flex gap-1 py-1">{[0, 1, 2].map((d) => <span key={d} className="w-1.5 h-1.5 rounded-full bg-black animate-bounce" style={{ animationDelay: `${d * 0.15}s` }} />)}</span>}
                  </div>
                </motion.div>
              ))}
              {msgs.length <= 1 && (
                <div className="flex flex-wrap gap-2 pt-1">
                  {SUGGEST.map((s) => <button key={s} onClick={() => send(s)} className="text-xs font-bold px-3 py-2 rounded-xl border-2 border-black bg-white hover:bg-yellow hover:-translate-y-0.5 transition font-serif">{s}</button>)}
                </div>
              )}
            </div>

            <form onSubmit={(e) => { e.preventDefault(); send(); }} className="p-3 border-t-2 border-black">
              <div className="flex items-end gap-2 rounded-2xl border-2 border-black bg-white p-1.5 focus-within:shadow-[3px_3px_0_#000] transition">
                <textarea ref={inputRef} value={input} onChange={(e) => setInput(e.target.value)} rows={1}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
                  placeholder="Ask about Ahmed…" className="flex-1 resize-none bg-transparent outline-none text-sm px-2.5 py-2 max-h-28" />
                <button disabled={busy || !input.trim()} className="w-10 h-10 shrink-0 rounded-xl bg-teal border-2 border-black grid place-items-center disabled:opacity-40 transition" aria-label="Send"><Send className="w-4 h-4" /></button>
              </div>
              <div className="text-[10px] text-black/55 text-center mt-1.5 inline-flex w-full justify-center items-center gap-1"><Cpu className="w-3 h-3" /> Answers come only from Ahmed's portfolio data.</div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

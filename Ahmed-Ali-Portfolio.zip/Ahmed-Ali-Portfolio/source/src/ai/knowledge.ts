import { PROFILE, ABOUT_POINTS, SERVICES, EXPERIENCE, SKILLS, PROJECTS, EDUCATION, BLOG, FAQ } from '../data';

/** Full portfolio knowledge, fed to the AI on every question. */
export function buildKnowledge(): string {
  const cats = [...new Set(SKILLS.map((s) => s.cat))];
  const skills = cats.map((c) => `- ${c}: ${SKILLS.filter((s) => s.cat === c).map((s) => `${s.name} (${s.note})`).join(', ')}`).join('\n');
  const projects = PROJECTS.map((p) =>
    `### ${p.title} [${p.client}]\n${p.summary}\nFeatures: ${p.points.join('; ')}\nProblem: ${p.problem}\nResult: ${p.result}\nStack: ${p.stack.join(', ')}\n` +
    (p.live ? `Demo: interactive demo built into this portfolio (Work → ${p.title} → Open live demo, or ${p.live})\n` : 'Demo: not public (client work)\n')).join('\n');
  const edu = EDUCATION.map((e) => `- ${e.degree}, ${e.school} (${e.year}) ${e.grade}${e.courses.length ? ' — ' + e.courses.join(', ') : ''}`).join('\n');
  const exp = EXPERIENCE.map((x) => `- ${x.role} — ${x.org} (${x.when}): ${x.points.join('; ')}`).join('\n');
  const services = SERVICES.map((s) => `- ${s.title}: ${s.points.join(', ')}`).join('\n');
  const blog = BLOG.map((b) => `- "${b.title}" — ${b.excerpt}`).join('\n');
  const faq = FAQ.map((f) => `- Q: ${f.q} A: ${f.a}`).join('\n');
  return `# Ahmed Ali — portfolio knowledge
Name: ${PROFILE.fullName}
Title: ${PROFILE.title}; roles: ${PROFILE.roles.join(', ')}
Current job: Oracle APEX & Database Developer at ${PROFILE.company} (Aug 2024 – present), contributing to the Public CareBox platform
Location: ${PROFILE.location} (time zone Asia/Karachi, PKT UTC+5)
Email / Gmail: ${PROFILE.email}
Phone & WhatsApp: ${PROFILE.phone} (${PROFILE.phoneIntl}) — https://wa.me/${PROFILE.whatsapp}
LinkedIn: ${PROFILE.linkedin}
GitHub: ${PROFILE.github}
Education headline: ${PROFILE.degree}, ${PROFILE.university}
Languages: ${PROFILE.languages.join(', ')}
Availability: ${PROFILE.availability}

## About
${ABOUT_POINTS.map((p) => '- ' + p).join('\n')}

## Services
${services}

## Experience
${exp}

## Technical skills
${skills}

## Projects
${projects}

## Education
${edu}

## Notes on the site
${blog}

## FAQ
${faq}

## Website sections
Home, Intro, Beliefs + stats, Tech strip, Services, Work (4 projects with previews), CareBox Lab (live demo: customers, CareBox orders, approval + signature + Apply, status workflow, admin dashboard), HeavyEquip Lab (live marketplace demo), Toolkit, Education, Experience, Notes, Let's Collaborate (form → Gmail / WhatsApp), footer with globe + live Pakistan time, light & dark mode, this AI assistant.`;
}

export const SYSTEM_PROMPT = `You are "Ahmed's AI", the assistant on Ahmed Ali's portfolio website. Visitors are recruiters, clients and developers.
Rules:
- Answer ONLY from the KNOWLEDGE below. Never invent employers, dates, salaries, certificates or numbers that are not there. If something is not in the knowledge, say you don't have that detail and suggest contacting Ahmed (Gmail or WhatsApp).
- Be point-to-point: short answer first, then 2–5 crisp bullet points if useful. No filler.
- Reply in the visitor's language and script (English, Urdu, Roman Urdu, Hindi, etc.).
- Speak about Ahmed in third person, warmly and professionally. Recommend him when relevant, without exaggeration.
- When the visitor wants to hire/contact, give: Gmail ahmedalisafdar1234@gmail.com, WhatsApp +92 308 0001661, LinkedIn link.
- Use simple markdown: **bold**, bullet lists with "- ", and plain URLs.`;

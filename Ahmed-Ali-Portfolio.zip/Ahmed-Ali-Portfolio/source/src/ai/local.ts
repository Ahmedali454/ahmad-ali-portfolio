import { PROFILE, SKILLS, PROJECTS, EDUCATION, EXPERIENCE, SERVICES, BLOG } from '../data';

// On-device answer engine (no server, no key). Used when Claude isn't available to this viewer.
// Understands English, Roman Urdu and Urdu/Hindi keywords.

type Intent = { id: string; keys: string[]; answer: (q: string) => string };

const norm = (s: string) => s.toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}\s+#.]/gu, ' ').replace(/\s+/g, ' ').trim();

const contact = () =>
  `**Contact Ahmed**\n- Gmail: ${PROFILE.email}\n- WhatsApp / Phone: ${PROFILE.phoneIntl}\n- LinkedIn: ${PROFILE.linkedin}\n- GitHub: ${PROFILE.github}`;

const cat = (c: string) => SKILLS.filter((s) => s.cat === c).map((s) => `- ${s.name} — ${s.note}`).join('\n');
const proj = (id: string) => { const p = PROJECTS.find((x) => x.id === id)!; return `**${p.title}** — ${p.summary}\n${p.points.map((x) => '- ' + x).join('\n')}\n- Stack: ${p.stack.join(', ')}${p.live ? `\n\nTry it: Work → ${p.title} → **Open live demo**.` : ''}`; };

const INTENTS: Intent[] = [
  { id: 'greet', keys: ['hi', 'hello', 'hey', 'salam', 'assalam', 'aoa', 'hola', 'سلام', 'नमस्ते', 'kaise', 'kese'],
    answer: () => `Hi! I'm Ahmed's AI. Ask me about his **Oracle APEX work, projects, skills, education** or how to **hire/contact** him.` },
  { id: 'contact', keys: ['contact', 'email', 'gmail', 'mail', 'phone', 'number', 'call', 'whatsapp', 'reach', 'hire', 'rabta', 'raabta', 'nmbr', 'رابطہ', 'نمبر', 'संपर्क', 'linkedin', 'github', 'social', 'links'],
    answer: contact },
  { id: 'location', keys: ['where', 'location', 'live', 'city', 'country', 'based', 'kahan', 'kaha', 'rehte', 'pakistan', 'hassan', 'abdal', 'کہاں', 'कहाँ', 'time', 'timezone'],
    answer: () => `Ahmed is based in **${PROFILE.location}** (PKT, UTC+5).\n- Open to remote, on-site and freelance work.` },
  { id: 'education', keys: ['education', 'degree', 'university', 'study', 'studied', 'cgpa', 'gpa', 'college', 'school', 'matric', 'fsc', 'parhai', 'padhai', 'taleem', 'تعلیم', 'शिक्षा', 'haripur', 'marks'],
    answer: () => `**Education**\n${EDUCATION.map((e) => `- **${e.degree}** — ${e.school} (${e.year})${e.grade ? `, ${e.grade}` : ''}`).join('\n')}` },
  { id: 'carebox', keys: ['carebox', 'care box', 'care', 'order', 'orders', 'approval', 'signature', 'apply', 'customer', 'customers'],
    answer: () => proj('public-carebox') },
  { id: 'dashboard', keys: ['dashboard', 'dashboards', 'statistics', 'stats', 'status', 'workflow', 'workflows', 'paused'],
    answer: () => proj('carebox-dashboards') },
  { id: 'api', keys: ['api', 'apis', 'rest', 'json', 'integration', 'sync', 'synchronization', 'auth', 'authentication', 'login', 'auto login', 'cookie', 'session'],
    answer: () => proj('carebox-api') },
  { id: 'heavy', keys: ['heavy', 'heavyequip', 'equipment', 'marketplace', 'fyp', 'final year', 'buyer', 'seller'],
    answer: () => proj('heavyequip') },
  { id: 'ispr', keys: ['ispr', 'intern', 'internship'],
    answer: () => { const x = EXPERIENCE[1]; return `**${x.role} — ${x.org}**\n- ${x.when}\n${x.points.map((p) => '- ' + p).join('\n')}`; } },
  { id: 'apex', keys: ['apex', 'oracle', 'low code', 'lowcode', 'interactive report', 'interactive grid', 'dynamic action', 'shared components'],
    answer: () => `**Oracle APEX**\n${cat('Oracle APEX')}\n\nUsed daily at ${PROFILE.company} on the Public CareBox platform.` },
  { id: 'db', keys: ['sql', 'plsql', 'pl sql', 'database', 'package', 'packages', 'procedure', 'procedures', 'function', 'functions', 'query'],
    answer: () => `**Database**\n${cat('Database')}` },
  { id: 'experience', keys: ['experience', 'work', 'job', 'worked', 'career', 'tajurba', 'tajurbah', 'تجربہ', 'अनुभव', 'company', 'role', 's&h', 'sh'],
    answer: () => `**Experience**\n${EXPERIENCE.map((x) => `- **${x.role}** — ${x.org} (${x.when})`).join('\n')}` },
  { id: 'projects', keys: ['project', 'projects', 'portfolio', 'built', 'build', 'app', 'apps', 'demo', 'live'],
    answer: () => `**Projects**\n${PROJECTS.map((p) => `- **${p.title}** — ${p.summary}`).join('\n')}\n\nCareBox and HeavyEquip have live demos on this site.` },
  { id: 'frontend', keys: ['html', 'css', 'javascript', 'js', 'frontend', 'front end', 'ui'],
    answer: () => `**Web / Front-End**\n${cat('Web / Front-End')}` },
  { id: 'skills', keys: ['skill', 'skills', 'tech', 'stack', 'technologies', 'tools', 'know', 'expert', 'strength', 'aata', 'aati', 'مہارت', 'कौशल', 'language', 'languages', 'urdu', 'english'],
    answer: () => {
      const cats = [...new Set(SKILLS.map((s) => s.cat))];
      return `**Skills**\n${cats.map((c) => `- **${c}:** ${SKILLS.filter((s) => s.cat === c).map((s) => s.name).join(', ')}`).join('\n')}`;
    } },
  { id: 'services', keys: ['service', 'services', 'offer', 'freelance', 'price', 'rate', 'cost', 'kya kar', 'what can'],
    answer: () => `**What Ahmed offers**\n${SERVICES.map((s) => `- **${s.title}:** ${s.points.join(', ')}`).join('\n')}\n\nFor pricing: ${PROFILE.email} / WhatsApp ${PROFILE.phoneIntl}.` },
  { id: 'blog', keys: ['blog', 'article', 'post', 'notes', 'writing'],
    answer: () => `**Notes**\n${BLOG.map((b) => `- ${b.title}`).join('\n')}` },
  { id: 'why', keys: ['why', 'should', 'hire him', 'best', 'good', 'recommend', 'kyun', 'kyu'],
    answer: () => `**Why Ahmed**\n- 2+ years building real Oracle APEX business apps at ${PROFILE.company}\n- Strong SQL & PL/SQL: packages, procedures, validations\n- REST API integration, authentication and data sync\n- Dashboards & workflow-driven apps (Public CareBox)\n\n${contact()}` },
  { id: 'about', keys: ['who', 'about', 'ahmed', 'ali', 'introduce', 'yourself', 'kaun', 'kon', 'bio', 'summary', 'کون', 'कौन', 'name'],
    answer: () => `**${PROFILE.fullName}** — ${PROFILE.title} from ${PROFILE.city}, Pakistan.\n- Oracle APEX & Database Developer at ${PROFILE.company} (Aug 2024 – present)\n- Oracle APEX, SQL, PL/SQL, REST APIs, JSON\n- Key project: Public CareBox\n- Software Engineering, University of Haripur (2026), CGPA 3.00` },
  { id: 'availability', keys: ['available', 'availability', 'open to', 'remote', 'relocate', 'notice'],
    answer: () => `Yes — ${PROFILE.availability}\n\n${contact()}` },
];

export function localAnswer(question: string): string {
  const q = ' ' + norm(question) + ' ';
  let best: { intent: Intent; score: number } | null = null;
  for (const intent of INTENTS) {
    let score = 0;
    for (const k of intent.keys) {
      const kk = k.toLowerCase();
      if (/^[a-z0-9 +#.]+$/.test(kk) ? q.includes(' ' + kk + ' ') || q.includes(' ' + kk + 's ') : q.includes(kk)) score += kk.length > 4 ? 2 : 1;
    }
    if (intent.id === 'greet' && q.trim().split(' ').length > 4) score -= 1;
    if (!best || score > best.score) best = { intent, score };
  }
  if (best && best.score > 0) return best.intent.answer(q);
  return `I don't have that detail. Here's what I can tell you about: skills, projects, experience, education, location and contact.\n\n${contact()}`;
}

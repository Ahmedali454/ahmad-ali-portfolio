// Bridge to Claude when the site is hosted as a claude.ai artifact (capability "sample").
// Elsewhere (GitHub Pages etc.) this resolves to null and the on-device engine answers.
type SampleFn = ((input: any, opts?: any) => Promise<{ text: string; truncated?: boolean }>) & { limits?: () => Promise<{ images?: boolean }> };
let cached: Promise<SampleFn | null> | null = null;

export function getSampler(): Promise<SampleFn | null> {
  if (cached) return cached;
  cached = new Promise((resolve) => {
    const start = Date.now();
    const tryUse = () => {
      const c = (window as any).claude;
      if (c && typeof c.use === 'function') {
        c.use('sample').then((s: SampleFn | null) => resolve(s || null)).catch(() => resolve(null));
      } else if (Date.now() - start < 4000) setTimeout(tryUse, 250);
      else resolve(null);
    };
    tryUse();
  });
  return cached;
}

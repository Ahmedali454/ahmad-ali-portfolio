import { useEffect, useRef, useState, ReactNode, CSSProperties } from 'react';
import { motion } from 'motion/react';
import {
  siReact, siTailwindcss, siHtml5, siCss3, siJavascript, siPython, siNodedotjs, siOracle, siMysql,
  siGithub, siKaggle, siGooglecolab, siGooglegemini, siWhatsapp, siGmail, siLinkedin, siJira, siVite, siTensorflow, siJson,
} from 'simple-icons';
import { Bug, ClipboardCheck, ShieldCheck, Brain, Rocket, Sparkles, Globe, Code2, Database, CheckCircle2, Zap, Table2, Grid3x3, Cog, GitBranch, KeyRound, Layers, Plug, Lock, RefreshCw, LayoutDashboard, Workflow, Search } from 'lucide-react';

/** 3D tilt + spotlight on pointer move. Disabled on touch devices. */
export function useTilt<T extends HTMLElement>(max = 10) {
  const ref = useRef<T>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || matchMedia('(hover: none)').matches) return;
    let raf = 0;
    const move = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        el.style.transform = `perspective(900px) rotateX(${(0.5 - py) * max}deg) rotateY(${(px - 0.5) * max}deg) scale3d(1.02,1.02,1.02)`;
        el.style.setProperty('--mx', `${px * 100}%`);
        el.style.setProperty('--my', `${py * 100}%`);
      });
    };
    const leave = () => { cancelAnimationFrame(raf); el.style.transform = ''; };
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerleave', leave);
    return () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerleave', leave); };
  }, [max]);
  return ref;
}

export function Tilt({ children, className = '', max = 10, style, onClick }: { children: ReactNode; className?: string; max?: number; style?: CSSProperties; onClick?: () => void }) {
  const ref = useTilt<HTMLDivElement>(max);
  return (
    <div ref={ref} className={`tilt relative ${className}`} style={style} onClick={onClick}>
      <div className="tilt-shine" />
      {children}
    </div>
  );
}

/** Magnetic hover for buttons */
export function useMagnet<T extends HTMLElement>(strength = 0.25) {
  const ref = useRef<T>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || matchMedia('(hover: none)').matches) return;
    const move = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      el.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * strength}px, ${(e.clientY - r.top - r.height / 2) * strength}px)`;
    };
    const leave = () => (el.style.transform = '');
    el.style.transition = 'transform .25s cubic-bezier(.2,.8,.2,1)';
    el.addEventListener('pointermove', move); el.addEventListener('pointerleave', leave);
    return () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerleave', leave); };
  }, [strength]);
  return ref;
}

export function Reveal({ children, delay = 0, className = '' }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div className={className} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.6, delay, ease: [0.16, 1, 0.3, 1] }}>
      {children}
    </motion.div>
  );
}

export function SectionHead({ kicker, title, sub }: { kicker: string; title: ReactNode; sub?: string }) {
  return (
    <Reveal className="mb-10 md:mb-14 max-w-3xl">
      <div className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-accent mb-3">
        <span className="h-px w-8 bg-accent" />{kicker}
      </div>
      <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight leading-[1.08]">{title}</h2>
      {sub && <p className="mt-4 text-muted text-base md:text-lg">{sub}</p>}
    </Reveal>
  );
}

export function useCountUp(target: number, run: boolean, ms = 1400) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!run) return;
    let start = 0; let raf = 0;
    const tick = (t: number) => {
      if (!start) start = t;
      const p = Math.min(1, (t - start) / ms);
      setV(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [run, target, ms]);
  return v;
}

const SI: Record<string, { path: string }> = {
  react: siReact, tailwind: siTailwindcss, html: siHtml5, css: siCss3, js: siJavascript, python: siPython,
  node: siNodedotjs, oracle: siOracle, sql: siMysql, github: siGithub, kaggle: siKaggle, colab: siGooglecolab,
  gemini: siGooglegemini, whatsapp: siWhatsapp, gmail: siGmail, linkedin: siLinkedin, jira: siJira, vite: siVite, tensorflow: siTensorflow, json: siJson,
};
const LU: Record<string, any> = { qa: ShieldCheck, cases: ClipboardCheck, bug: Bug, brain: Brain, rocket: Rocket, spark: Sparkles, globe: Globe, vscode: Code2, db: Database,
  check: CheckCircle2, zap: Zap, table: Table2, grid: Grid3x3, cog: Cog, branch: GitBranch, key: KeyRound, layers: Layers, plug: Plug, lock: Lock, sync: RefreshCw, dash: LayoutDashboard, flow: Workflow, shield: ShieldCheck, search: Search };

export function BrandIcon({ name, size = 22, color, className = '' }: { name: string; size?: number; color?: string; className?: string }) {
  const s = SI[name];
  if (s) return (
    <svg viewBox="0 0 24 24" width={size} height={size} className={className} fill={color || 'currentColor'} aria-hidden>
      <path d={s.path} />
    </svg>
  );
  const L = LU[name] || Sparkles;
  return <L width={size} height={size} className={className} style={{ color }} />;
}

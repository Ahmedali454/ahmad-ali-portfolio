import { ReactNode } from 'react';

function inline(text: string, key: string): ReactNode[] {
  const out: ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|https?:\/\/[^\s)]+|[\w.+-]+@[\w-]+\.[\w.]+)/g;
  let last = 0; let m: RegExpExecArray | null; let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    const t = m[0];
    if (t.startsWith('**')) out.push(<strong key={key + i++}>{t.slice(2, -2)}</strong>);
    else if (t.startsWith('http')) out.push(<a key={key + i++} href={t} target="_blank" rel="noopener noreferrer" className="text-accent underline underline-offset-2 break-all">{t.replace(/^https?:\/\//, '').replace(/\/$/, '')}</a>);
    else out.push(<a key={key + i++} href={`https://mail.google.com/mail/?view=cm&fs=1&to=${t}`} target="_blank" rel="noopener noreferrer" className="text-accent underline underline-offset-2 break-all">{t}</a>);
    last = m.index + t.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

export function Markdown({ text, className = '' }: { text: string; className?: string }) {
  const lines = text.split('\n');
  const blocks: ReactNode[] = [];
  let list: string[] = [];
  const flush = (k: number) => { if (list.length) { blocks.push(<ul key={'u' + k} className="list-disc pl-5 space-y-1 my-1.5">{list.map((l, j) => <li key={j}>{inline(l, `l${k}-${j}-`)}</li>)}</ul>); list = []; } };
  lines.forEach((raw, k) => {
    const l = raw.trimEnd();
    if (/^\s*([-*•]|\d+\.)\s+/.test(l)) { list.push(l.replace(/^\s*([-*•]|\d+\.)\s+/, '')); return; }
    flush(k);
    if (!l.trim()) return;
    if (/^#{1,4}\s/.test(l)) blocks.push(<h3 key={k}>{inline(l.replace(/^#+\s/, ''), 'h' + k)}</h3>);
    else blocks.push(<p key={k} className="my-1">{inline(l, 'p' + k)}</p>);
  });
  flush(lines.length);
  return <div className={className}>{blocks}</div>;
}

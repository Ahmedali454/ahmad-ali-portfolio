import { lazy, Suspense, useEffect, useState } from 'react';
import { Menu } from './components/Menu';
import { Hero } from './components/Hero';
import { Intro } from './components/Intro';
import { Believe } from './components/Believe';
import { LogoStrip, Services } from './components/Services';
import { Toolkit } from './components/Toolkit';
import { Work } from './components/Work';
import { Education } from './components/Education';
import { Mentions } from './components/Mentions';
import { Collab, Footer } from './components/Collab';
import ChatBot from './components/ChatBot';
import WhatsApp from './components/WhatsApp';

const CareBoxLab = lazy(() => import('./components/CareBoxLab'));
const HeavyEquipLab = lazy(() => import('./components/HeavyEquipLab'));

const LABS = ['#carebox-lab', '#heavyequip-lab'];

export default function App() {
  const [hash, setHash] = useState(() => location.hash);
  const [dark, setDark] = useState(() => document.documentElement.classList.contains('dark'));

  useEffect(() => {
    const h = () => {
      const prevLab = LABS.includes(hash);
      const next = location.hash; setHash(next);
      if (prevLab && !LABS.includes(next)) {
        // coming back from a lab: scroll to the requested section after render
        requestAnimationFrame(() => setTimeout(() => document.querySelector(next || '#top')?.scrollIntoView(), 60));
      }
    };
    addEventListener('hashchange', h); return () => removeEventListener('hashchange', h);
  }, [hash]);

  const toggleTheme = () => {
    const d = !dark; setDark(d);
    document.documentElement.classList.toggle('dark', d);
    try { localStorage.setItem('aa-theme', d ? 'dark' : 'light'); } catch { /* ignore */ }
  };

  const lab = LABS.includes(hash) ? hash : null;

  return (
    <>
      <Menu dark={dark} toggleTheme={toggleTheme} onLab={!!lab} />
      {lab ? (
        <Suspense fallback={<div className="min-h-screen bg-black" />}>
          {lab === '#carebox-lab' ? <CareBoxLab /> : <HeavyEquipLab />}
        </Suspense>
      ) : (
        <main>
          <Hero />
          <Intro />
          <Believe />
          <LogoStrip />
          <Services />
          <Work />
          <Toolkit />
          <Education />
          <Mentions />
          <Collab />
        </main>
      )}
      <Footer />
      <WhatsApp />
      <ChatBot />
    </>
  );
}

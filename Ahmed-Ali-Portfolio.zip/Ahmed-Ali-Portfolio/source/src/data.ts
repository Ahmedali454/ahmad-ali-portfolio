import avatar from './assets/ahmed2.jpg';
import imgCarebox from './assets/work/carebox.webp';
import imgApi from './assets/work/carebox-api.webp';
import imgDash from './assets/work/carebox-dashboard.webp';
import imgHeavy from './assets/work/heavyequip.webp';

export const PROFILE = {
  fullName: 'Ahmed Ali',
  first: 'AHMED',
  last: 'ALI',
  shortName: 'Ahmed Ali',
  title: 'Oracle APEX & Database Developer',
  roles: ['Oracle APEX Developer', 'Database Developer', 'PL/SQL Developer', 'REST API Integration', 'Software Engineer'],
  tagline: 'I build business applications with Oracle APEX, Oracle Database, SQL and PL/SQL — with REST APIs, authentication and data sync.',
  avatar,
  avatarSm: avatar,
  location: 'Hassan Abdal, Punjab, Pakistan',
  city: 'Hassan Abdal',
  coords: { lat: 33.8195, lng: 72.689 },
  timezone: 'Asia/Karachi',
  email: 'ahmedalisafdar1234@gmail.com',
  phone: '0308-0001661',
  phoneIntl: '+92 308 0001661',
  whatsapp: '923080001661',
  github: 'https://github.com/Ahmedali454',
  githubUser: 'Ahmedali454',
  linkedin: 'https://www.linkedin.com/in/ahmed-ali-7b364535b',
  company: 'S&H Software Solution',
  university: 'University of Haripur',
  degree: 'Software Engineering (2026), CGPA 3.00',
  languages: ['Urdu (native)', 'English (professional working proficiency)'],
  availability: 'Open to Oracle APEX, PL/SQL, database and integration roles — remote, on-site or freelance.',
};

export const gmailCompose = (subject = 'Hello Ahmed — from your portfolio', body = '') =>
  `https://mail.google.com/mail/?view=cm&fs=1&to=${PROFILE.email}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
export const waLink = (text: string) => `https://wa.me/${PROFILE.whatsapp}?text=${encodeURIComponent(text)}`;

export const ABOUT_POINTS = [
  'Oracle APEX & Database Developer at S&H Software Solution (Aug 2024 – present).',
  'Turns business requirements into working APEX applications.',
  'PL/SQL packages, procedures, functions, validations and application processes.',
  'REST API integration with JSON — API authentication and data synchronization.',
  'Dashboards & workflows: Interactive Reports, Interactive Grids, Dynamic Actions, Shared Components.',
  'Currently contributing to the Public CareBox platform.',
  'Software Engineering, University of Haripur (2026) — CGPA 3.00.',
];

export const STATS = [
  { value: 2, suffix: '+ yrs', label: 'Oracle APEX experience' },
  { value: 4, suffix: '', label: 'CareBox status workflows' },
  { value: 6, suffix: ' wks', label: 'ISPR internship' },
  { value: 3, suffix: '.00', label: 'CGPA — Software Eng.' },
];

export const SERVICES = [
  { icon: 'Database', title: 'Oracle APEX Apps', points: ['Business apps from requirements', 'Forms, validations & page processes', 'Interactive Reports & Grids'] },
  { icon: 'Code2', title: 'SQL & PL/SQL', points: ['Packages, procedures, functions', 'Business logic & data integrity', 'Query tuning & troubleshooting'] },
  { icon: 'Plug', title: 'REST API Integration', points: ['JSON APIs to external systems', 'API authentication', 'Customer / order data sync'] },
  { icon: 'LayoutDashboard', title: 'Dashboards & Workflows', points: ['Admin dashboards & statistics', 'Status & approval workflows', 'UI polish with JS, CSS, HTML'] },
];

export const EXPERIENCE = [
  {
    role: 'Oracle APEX & Database Developer',
    org: 'S&H Software Solution',
    when: 'Aug 2024 – Present',
    points: [
      'Builds and maintains business apps with Oracle APEX, Oracle Database, SQL and PL/SQL',
      'PL/SQL packages, procedures, functions, validations and application processes',
      'REST API integration — API authentication and data synchronization',
      'Dashboards & workflows with Interactive Reports/Grids, Dynamic Actions, Shared Components',
      'Troubleshoots SQL, PL/SQL, session-state, API and workflow issues',
    ],
    tags: ['Oracle APEX', 'PL/SQL', 'REST APIs', 'JavaScript'],
  },
  {
    role: 'Summer Intern',
    org: 'ISPR (Inter-Services Public Relations)',
    when: 'Jul 7 – Aug 15, 2025 · 6 weeks',
    points: ['Practical exposure to professional IT and workplace processes', 'Collaborated with team members on assigned tasks'],
    tags: ['IT Operations', 'Teamwork'],
  },
  {
    role: 'Final Year Project',
    org: 'HeavyEquip Marketplace — University of Haripur',
    when: '2026',
    points: ['Online marketplace connecting heavy-equipment buyers and sellers', 'Listings, user features, equipment/product management', 'Workflows, database, UI development and testing'],
    tags: ['Oracle APEX', 'JavaScript', 'HTML', 'CSS'],
  },
];

export type SkillCat = 'Database' | 'Oracle APEX' | 'API & Integration' | 'Web / Front-End' | 'App Development' | 'Languages';
export interface Skill { name: string; cat: SkillCat; note: string; icon: string; color: string }

export const SKILLS: Skill[] = [
  { name: 'Oracle Database', cat: 'Database', note: 'Schema, data & business logic', icon: 'oracle', color: '#F80000' },
  { name: 'SQL', cat: 'Database', note: 'Queries, joins, reporting', icon: 'sql', color: '#00618A' },
  { name: 'PL/SQL Packages', cat: 'Database', note: 'Packages, procedures, functions', icon: 'db', color: '#C2410C' },
  { name: 'Data Validation', cat: 'Database', note: 'Validations & data integrity', icon: 'check', color: '#16A34A' },
  { name: 'Troubleshooting', cat: 'Database', note: 'SQL / PL/SQL debugging', icon: 'bug', color: '#EC4899' },
  { name: 'Dynamic Actions', cat: 'Oracle APEX', note: 'Client-side behaviour, no page reload', icon: 'zap', color: '#F59E0B' },
  { name: 'Interactive Reports', cat: 'Oracle APEX', note: 'Filters, highlights, saved views', icon: 'table', color: '#0EA5E9' },
  { name: 'Interactive Grids', cat: 'Oracle APEX', note: 'Editable data grids', icon: 'grid', color: '#6366F1' },
  { name: 'Page & App Processes', cat: 'Oracle APEX', note: 'Server-side processing', icon: 'cog', color: '#64748B' },
  { name: 'Server-side Conditions', cat: 'Oracle APEX', note: 'Show / hide by state & role', icon: 'branch', color: '#14B8A6' },
  { name: 'Session State & Items', cat: 'Oracle APEX', note: 'Application & page items', icon: 'key', color: '#A855F7' },
  { name: 'Shared Components', cat: 'Oracle APEX', note: 'LOVs, auth, templates', icon: 'layers', color: '#F80000' },
  { name: 'REST APIs', cat: 'API & Integration', note: 'External system integration', icon: 'plug', color: '#10B981' },
  { name: 'JSON', cat: 'API & Integration', note: 'Payloads & parsing', icon: 'json', color: '#111111' },
  { name: 'API Authentication', cat: 'API & Integration', note: 'Secure API calls', icon: 'lock', color: '#EF4444' },
  { name: 'Data Synchronization', cat: 'API & Integration', note: 'Customer / order sync', icon: 'sync', color: '#06B6D4' },
  { name: 'JavaScript', cat: 'Web / Front-End', note: 'APEX UI enhancements', icon: 'js', color: '#F7DF1E' },
  { name: 'HTML', cat: 'Web / Front-End', note: 'Page markup', icon: 'html', color: '#E34F26' },
  { name: 'CSS', cat: 'Web / Front-End', note: 'Styling & UI polish', icon: 'css', color: '#3B82F6' },
  { name: 'Dashboards', cat: 'App Development', note: 'Admin stats & charts', icon: 'dash', color: '#8B5CF6' },
  { name: 'Forms & Workflows', cat: 'App Development', note: 'Approvals, status flows', icon: 'flow', color: '#0D9488' },
  { name: 'Authentication', cat: 'App Development', note: 'Login & auto-login flows', icon: 'shield', color: '#22C55E' },
  { name: 'App Debugging', cat: 'App Development', note: 'Finding root causes fast', icon: 'search', color: '#F97316' },
  { name: 'Urdu', cat: 'Languages', note: 'Native', icon: 'globe', color: '#22C55E' },
  { name: 'English', cat: 'Languages', note: 'Professional working proficiency', icon: 'globe', color: '#0EA5E9' },
];

export type ProjectCat = 'Enterprise' | 'Integration' | 'Marketplace';
export interface Project {
  id: string; title: string; cat: ProjectCat; summary: string; points: string[];
  problem: string; result: string; stack: string[];
  live?: string; liveLabel?: string; code?: string; status: 'Live' | 'Demo' | 'Client / Private' | 'In progress';
  cover: { from: string; to: string; icon: string };
  img?: string; client?: string;
}

export const PROJECTS: Project[] = [
  {
    id: 'public-carebox', title: 'Public CareBox', cat: 'Enterprise', status: 'Demo', live: '#carebox-lab', liveLabel: 'Open live demo',
    img: imgCarebox, client: 'S&H Software Solution · Oracle APEX',
    summary: 'Multi-application CareBox management platform — customers, orders, approvals.',
    points: [
      'Customer management & CareBox ordering — care products, quantities, order details',
      'Customer approval, signature and final Apply (submission) process',
      'Status workflows: active, inactive, paused, deleted — driving UI behaviour',
      'PL/SQL packages, validations, page processes, Interactive Reports/Grids',
    ],
    problem: 'Care-product orders needed one place for customers, product quantities, approvals and signatures.',
    result: 'A multi-app APEX platform where each CareBox moves from order → approval → signature → Apply.',
    stack: ['Oracle APEX', 'Oracle Database', 'SQL', 'PL/SQL', 'JavaScript', 'HTML', 'CSS'],
    cover: { from: '#0f766e', to: '#34eadd', icon: 'Package' },
  },
  {
    id: 'carebox-dashboards', title: 'CareBox Admin Dashboards', cat: 'Enterprise', status: 'Demo', live: '#carebox-lab', liveLabel: 'Open live demo',
    img: imgDash, client: 'Public CareBox · Dashboards',
    summary: 'Admin dashboards with customer & CareBox statistics and status management.',
    points: [
      'Statistics for current month, previous month and last 3 months',
      'Customer and CareBox counts by status',
      'Status changes drive what the UI shows (server-side conditions)',
      'Interactive Reports with filters and saved views',
    ],
    problem: 'Admins needed a quick view of how many customers and CareBoxes moved each period.',
    result: 'One dashboard page with period stats and status breakdowns, built on PL/SQL queries.',
    stack: ['Oracle APEX', 'SQL', 'PL/SQL', 'Interactive Reports', 'Dynamic Actions'],
    cover: { from: '#7c2d12', to: '#ffd527', icon: 'LayoutDashboard' },
  },
  {
    id: 'carebox-api', title: 'REST API Sync & Auto-Login', cat: 'Integration', status: 'Client / Private',
    img: imgApi, client: 'Public CareBox · Integration',
    summary: 'JSON REST APIs for customer/order sync + auto-login between APEX apps.',
    points: [
      'REST APIs for external customer and order synchronization using JSON',
      'API authentication for secure calls',
      'Customer authentication across applications',
      'Auto-login flow using application items and session/cookie handling',
    ],
    problem: 'Customer and order data lived in external systems, and users had to log in again in every app.',
    result: 'Data stays in sync through JSON APIs, and users move between apps without a second login.',
    stack: ['Oracle APEX', 'REST APIs', 'JSON', 'PL/SQL', 'Application Items', 'Session State'],
    cover: { from: '#312e81', to: '#a855f7', icon: 'Plug' },
  },
  {
    id: 'heavyequip', title: 'HeavyEquip Marketplace', cat: 'Marketplace', status: 'Demo', live: '#heavyequip-lab', liveLabel: 'Open live demo',
    img: imgHeavy, client: 'Final Year Project · Oracle APEX',
    summary: 'Online marketplace for buying, selling and managing heavy equipment.',
    points: [
      'Equipment listings connecting buyers and sellers',
      'User-related features and equipment/product management',
      'Application workflows and database functionality',
      'UI development and testing',
    ],
    problem: 'Buyers and sellers of heavy equipment had no simple, dedicated place to meet.',
    result: 'An APEX marketplace where sellers list machines and buyers browse, filter and enquire.',
    stack: ['Oracle APEX', 'JavaScript', 'HTML', 'CSS'],
    cover: { from: '#78350f', to: '#facc15', icon: 'Truck' },
  },
];

export const EDUCATION = [
  {
    degree: 'Software Engineering', school: 'University of Haripur', place: 'Haripur, KP', year: '2026', grade: 'CGPA 3.00',
    courses: ['Final Year Project: HeavyEquip Marketplace (Oracle APEX)'],
  },
  {
    degree: 'FSc (Faculty of Science)', school: 'Degree College Hassan Abdal', place: 'Hassan Abdal', year: '2021', grade: 'Marks: 849',
    courses: [] as string[],
  },
  {
    degree: 'Matriculation', school: 'The Educators, Abdalian Campus', place: 'Hassan Abdal', year: '2019', grade: 'Marks: 816',
    courses: [] as string[],
  },
];

export const BLOG = [
  {
    id: 'rest', title: 'Syncing APEX with External Systems over REST + JSON', tag: 'API & Integration', read: '4 min', date: 'Oct 2026',
    excerpt: 'How customer and order data stays in sync between an APEX app and an external API.',
    body: `### The flow
- **Authenticate** — get a token before every sync run.
- **Fetch JSON** — customers and orders from the external system.
- **Parse & merge** — PL/SQL parses the JSON and merges rows into Oracle tables.
- **Log** — every run writes a status row, so failures are easy to trace.

### Lesson
Keep the sync logic in a PL/SQL package, not in page processes — one place to fix, test and reuse.`,
  },
  {
    id: 'autologin', title: 'Auto-Login Between APEX Applications', tag: 'Oracle APEX', read: '3 min', date: 'Sep 2026',
    excerpt: 'Moving a signed-in customer from one APEX app to another without a second login.',
    body: `### Building blocks
- **Application items** hold the authenticated customer.
- **Session / cookie handling** carries the identity to the next app.
- **Server-side checks** confirm the user before any page renders.

### Why it matters
Customers see one product, even when it is several APEX applications behind the scenes.`,
  },
  {
    id: 'status', title: 'Status Workflows that Drive the UI', tag: 'App Development', read: '3 min', date: 'Aug 2026',
    excerpt: 'Active, inactive, paused, deleted — letting a status column decide what users can do.',
    body: `### Pattern
- One **status** column, four values: active, inactive, paused, deleted.
- **Server-side conditions** show or hide buttons and regions by status.
- **Dynamic Actions** refresh regions the moment a status changes.

### Result
Fewer pages, fewer mistakes — the UI always matches the data.`,
  },
];

export const FAQ = [
  { q: 'Are you available for work?', a: 'Open to Oracle APEX, PL/SQL, database and integration roles — remote, on-site or freelance.' },
  { q: 'Fastest way to reach you?', a: 'WhatsApp +92 308 0001661 or Gmail ahmedalisafdar1234@gmail.com.' },
  { q: 'Where do you work now?', a: 'Oracle APEX & Database Developer at S&H Software Solution since Aug 2024.' },
  { q: 'What do you build best?', a: 'Oracle APEX business apps with PL/SQL logic, dashboards, workflows and REST API integration.' },
];

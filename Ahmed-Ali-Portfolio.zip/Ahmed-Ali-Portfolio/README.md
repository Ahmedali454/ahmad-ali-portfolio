# Ahmed Ali — Portfolio

Bold keycap-style portfolio: AI assistant, Work with live website screenshots, Plant Disease Lab, Bike Management System demo, light/dark mode, Gmail + WhatsApp contact.

## 1. Open it on your PC (no install)
Open `website/index.html` in Chrome / Edge. Everything (fonts, images, demos) is inside that one file.
> The AI chat answers from the built-in smart engine offline. On claude.ai it uses Claude.

## 2. Make it live for your CV — free, 2 options

### Option A — Netlify Drop (easiest, 1 minute)
1. Go to https://app.netlify.com/drop and sign in (free).
2. Drag the **`website`** folder onto the page.
3. You get a link like `https://something.netlify.app` → Site settings → Change site name → e.g. `usman-ramzan.netlify.app`.

### Option B — GitHub Pages (best for a developer CV)
1. On GitHub (account **MAhmedCodes**) create a new public repo named exactly **`MAhmedCodes.github.io`**.
2. Click **Add file → Upload files**, drop `website/index.html` and `website/og-image.webp`, then **Commit**.
3. Repo → **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main` / root → Save.
4. In 1–2 minutes the site is live at **https://musmancodes.github.io**

Put that link in your CV, LinkedIn "Featured", and GitHub profile.

## 3. Edit the content
All text/data lives in `source/src/data.ts` (profile, skills, projects, education, experience, blog, FAQ).
LinkedIn link: `PROFILE.linkedin` in the same file.

```bash
cd source
npm install
npm run dev            # local preview at http://localhost:3000
npm run build:single   # → dist-single/index.html (one file, same as website/index.html)
npm run build          # → dist/ (multi-file build)
```
Pushing `source` to a GitHub repo also auto-deploys via `.github/workflows/deploy.yml` (gh-pages branch).

## Structure
- `src/components/Hero.tsx` — photo hero, draggable "Available" sticker
- `Intro.tsx`, `Believe.tsx`, `Services.tsx`, `Work.tsx`, `Toolkit.tsx`, `Education.tsx`, `Mentions.tsx`, `Collab.tsx`
- `BikeLab.tsx` (`#bike-lab`), `PlantLab.tsx` (`#plant-lab`)
- `ChatBot.tsx` + `src/ai/` — AI assistant (Claude when available, offline engine otherwise)
- `src/assets/work/` — project screenshots
